"""
Matrix-free Newton-Conjugate-Gradient Total-Lagrangian FEM solver, built
specifically to reach the advisor's requested ~10 million DOF mesh-
convergence reference. Every other solver in this codebase (the CPU
reference in data/data_generate_B1.py / B2.py, and the GPU-native batched
solver in gpu_fem_solver.py) explicitly FORMS the tangent stiffness matrix
-- a sparse matrix on CPU, a dense per-sample matrix on GPU -- and neither
approach scales to millions of DOF: a direct sparse factorization's fill-in
blows up memory in 2D well before 10M unknowns, and a dense matrix at that
size is simply impossible to store (10M^2 entries).

This solver instead NEVER forms the tangent matrix K. It only ever needs
Hessian-VECTOR products K @ v, computed via forward-over-reverse automatic
differentiation (torch.func.jvp composed with torch.func.grad) -- exactly
the same trick used everywhere else in this codebase to avoid hand-deriving
tangents (see gpu_fem_solver.py's own docstring), taken one step further:
here we differentiate through the RESIDUAL's action on a direction, rather
than materializing the full second derivative. Memory cost is O(DOF) (a
handful of vectors), not O(DOF^2) or O(nnz fill-in), which is what makes
pushing to millions of DOF possible on a single GPU at all.

The resulting linear system at each Newton step is then solved with
(unpreconditioned) Conjugate Gradient using only these Hv products --
appropriate because the Hessian of a scalar energy functional is symmetric
by construction, and positive definite in a neighborhood of a stable
equilibrium for a physically stable hyperelastic material. No
preconditioner is implemented in this first version (a Jacobi/diagonal
preconditioner would need each node's own diagonal stiffness contribution,
which is cheap to get from LOCAL per-element Hessians but is left as
future work); if CG fails to converge within --cg_max_iter, this is
reported explicitly rather than silently returning a wrong answer.

Supports both Q4 (bilinear) and Q9 (biquadratic, data/q9_element.py)
elements through one shared, order-agnostic energy assembly, so the same
solver produces the polynomial-order comparison the advisor asked for.

Correctness: validated against the existing CPU reference solver at small
N (see validate_matrix_free_solver.py) before this is trusted for anything
larger -- exactly the same discipline gpu_fem_solver.py's own
validate_gpu_fem_solver.py already established for the batched GPU solver.
"""
import os
import time
import numpy as np
import torch
from torch.func import grad, jvp, hessian, vmap

from omar_pfem.data.fem_core import shape_Q4
from omar_pfem.data.q9_element import shape_Q9, gauss_3x3
from omar_pfem.materials_torch import get_material_fns as get_material_fns_torch


def _gauss_2x2():
    g = 1.0 / np.sqrt(3.0)
    return [(-g, -g, 1.0), (g, -g, 1.0), (g, g, 1.0), (-g, g, 1.0)]


def _shape_fn_and_quadrature(order):
    if order == "Q4":
        return shape_Q4, _gauss_2x2()
    elif order == "Q9":
        return shape_Q9, gauss_3x3()
    raise ValueError(order)


def precompute_shape_data(order, device, dtype):
    """Precomputes (N, dN_dxi) at every Gauss point once, as constant
    tensors reused for every element/sample -- these depend only on the
    reference element, never on nodal coordinates or material."""
    shape_fn, gauss = _shape_fn_and_quadrature(order)
    Ns, dNs, ws = [], [], []
    for (xi, eta, w) in gauss:
        N, dN_dxi = shape_fn(xi, eta)
        Ns.append(torch.tensor(N, dtype=dtype, device=device))
        dNs.append(torch.tensor(dN_dxi, dtype=dtype, device=device))
        ws.append(w)
    return Ns, dNs, ws


def element_energy_order_agnostic(xy, quad, uv, elem_params, energy_density_fn, shape_data, dtype):
    """Total internal energy U(u) = sum over elements and Gauss points of
    psi(F) dV0, for EITHER Q4 or Q9 (order determined entirely by quad's
    number of columns and shape_data's length -- 4 Gauss points for Q4, 9
    for Q9). Vectorized over all elements at once via the quad index
    tensor, exactly mirroring gpu_fem_solver._element_energy_Q4's
    approach, generalized from a hardcoded 4 local nodes to however many
    quad.shape[1] actually is.

    Each entry of elem_params is either (n_elements,), one value reused at
    every Gauss point, or (n_elements, n_gauss), one value per Gauss point.
    B2's reference solver samples the material per Gauss point, so its
    parameters arrive in the second form; B1's samples at the centroid and
    arrives in the first. The Gauss ordering here is the same list this
    module's own _shape_fn_and_quadrature returns, which is verified equal
    to gpu_fem_solver's and fem_core's, so column g belongs to Gauss point
    g in all three."""
    Ns, dNs, ws = shape_data
    Xe = xy[quad]   # (Q, n_local, 2)
    ue = uv[quad]   # (Q, n_local, 2)

    U = torch.zeros((), device=xy.device, dtype=dtype)
    for g_idx, (N, dN_dxi, w) in enumerate(zip(Ns, dNs, ws)):
        J0 = torch.einsum("qai,aj->qij", Xe, dN_dxi)
        detJ0 = J0[:, 0, 0] * J0[:, 1, 1] - J0[:, 0, 1] * J0[:, 1, 0]
        detJ0 = torch.clamp(detJ0, min=1e-12)

        invJ0 = torch.zeros_like(J0)
        invJ0[:, 0, 0] = J0[:, 1, 1] / detJ0
        invJ0[:, 1, 1] = J0[:, 0, 0] / detJ0
        invJ0[:, 0, 1] = -J0[:, 0, 1] / detJ0
        invJ0[:, 1, 0] = -J0[:, 1, 0] / detJ0

        dN_dX = torch.einsum("aj,qjk->qak", dN_dxi, invJ0)
        grad_u = torch.einsum("qai,qaj->qij", ue, dN_dX)

        I = torch.eye(2, device=xy.device, dtype=dtype).reshape(1, 2, 2).expand(Xe.shape[0], 2, 2)
        F = I + grad_u

        gp_params = tuple(p[:, g_idx] if p.dim() == 2 else p for p in elem_params)
        psi = energy_density_fn(F, *gp_params, dtype=dtype)
        U = U + torch.sum(psi * detJ0 * w)
    return U


def _local_element_energy(ue_flat, Xe, elem_param_tuple, energy_density_fn, shape_data, dtype):
    """Internal energy of ONE element, as a function of its own flattened
    nodal displacement (2*n_local,) -- small enough (8 or 18 entries) that
    its own Hessian is cheap, unlike the global tangent this whole module
    exists to avoid forming."""
    n_local = Xe.shape[0]
    ue = ue_flat.reshape(n_local, 2)
    Ns, dNs, ws = shape_data
    U = torch.zeros((), device=Xe.device, dtype=dtype)
    for g_idx, (N, dN_dxi, w) in enumerate(zip(Ns, dNs, ws)):
        J0 = torch.einsum("ai,aj->ij", Xe, dN_dxi)
        detJ0 = J0[0, 0] * J0[1, 1] - J0[0, 1] * J0[1, 0]
        detJ0 = torch.clamp(detJ0, min=1e-12)
        invJ0 = torch.stack([torch.stack([J0[1, 1] / detJ0, -J0[0, 1] / detJ0]),
                              torch.stack([-J0[1, 0] / detJ0, J0[0, 0] / detJ0])])
        dN_dX = dN_dxi @ invJ0
        grad_u = torch.einsum("ai,aj->ij", ue, dN_dX)
        F = torch.eye(2, device=Xe.device, dtype=dtype) + grad_u
        # energy_density_fn expects a leading batch dim (F[:, 0, 0]-style
        # indexing) -- add and remove a size-1 one, this is a single element.
        # one element's params: either a scalar (centroid sampling) or one
        # value per Gauss point, of which this iteration wants the g_idx'th
        params_1 = tuple((p[g_idx] if p.dim() >= 1 and p.numel() > 1 else p).reshape(1)
                         for p in elem_param_tuple)
        psi = energy_density_fn(F.unsqueeze(0), *params_1, dtype=dtype)[0]
        U = U + psi * detJ0 * w
    return U


def compute_jacobi_diagonal(xy, quad, uv_full, elem_params, material, order, dtype, free_dofs,
                             chunk_size=200_000):
    """Global diagonal of the tangent stiffness at the CURRENT displacement
    uv_full, computed WITHOUT ever forming the global (or even any element's
    full local) matrix explicitly beyond its own small diagonal: each
    element's local Hessian (cheap: 8x8 for Q4, 18x18 for Q9) is computed
    via vmap+hessian, its diagonal extracted, and scatter-added into the
    global diagonal by connectivity. This is the exact diagonal of K (sum of
    every element's own diagonal contribution at each shared node), not an
    approximation -- the standard, cheap way to build a Jacobi
    preconditioner for a matrix-free solver.

    chunk_size: the vmap batch is run over this many elements at a time
    instead of all Q elements at once. Mathematically this changes nothing
    (each chunk's local Hessians are independent of every other chunk's --
    same exact diagonal, just accumulated in pieces), but it bounds peak
    memory to O(chunk_size) instead of O(Q): at Q9's 18x18 local Hessian
    (5.06x Q4's 8x8) and millions of elements, materializing every
    element's local Hessian in one vmap call is what actually exhausted an
    80GB A100 at ~40M DOF (fine_N=2236) -- the CG loop itself never forms
    anything bigger than a handful of length-DOF vectors, so this one-shot
    preconditioner setup was the sole memory bottleneck."""
    n_nodes = xy.shape[0]
    ndof = 2 * n_nodes
    energy_density_fn, _ = get_material_fns_torch(material)
    shape_data = precompute_shape_data(order, xy.device, dtype)

    Xe_all = xy[quad]                       # (Q, n_local, 2)
    ue_all = uv_full.reshape(n_nodes, 2)[quad].reshape(Xe_all.shape[0], -1)  # (Q, 2*n_local)
    dof_idx = torch.stack([2 * quad, 2 * quad + 1], dim=-1).reshape(quad.shape[0], -1)  # (Q, 2*n_local)

    local_hess_fn = hessian(_local_element_energy, argnums=0)
    batched_hess = vmap(local_hess_fn, in_dims=(0, 0, 0, None, None, None))

    global_diag = torch.zeros(ndof, device=xy.device, dtype=dtype)
    n_elem = Xe_all.shape[0]
    for start in range(0, n_elem, chunk_size):
        end = min(start + chunk_size, n_elem)
        elem_params_chunk = tuple(p[start:end] for p in elem_params)
        H_local = batched_hess(ue_all[start:end], Xe_all[start:end], elem_params_chunk,
                                energy_density_fn, shape_data, dtype)  # (chunk, 2nl, 2nl)
        diag_local = torch.diagonal(H_local, dim1=-2, dim2=-1)  # (chunk, 2*n_local)
        global_diag.scatter_add_(0, dof_idx[start:end].reshape(-1), diag_local.reshape(-1))

    diag_free = global_diag[free_dofs]
    # Guard against a (rare, near-singular) near-zero diagonal entry, which
    # would blow up the preconditioner rather than merely slow it down.
    diag_free = torch.where(diag_free.abs() > 1e-10, diag_free, torch.ones_like(diag_free))
    return diag_free


def compute_block_jacobi(xy, quad, uv_full, elem_params, material, order, dtype,
                          chunk_size=200_000):
    """Global 2x2 block-diagonal of the tangent stiffness at the CURRENT
    displacement uv_full: same construction as compute_jacobi_diagonal
    (local per-element Hessians via vmap+hessian, scatter-added by
    connectivity, chunked to bound memory), generalized from a 1x1 diagonal
    entry per DOF to a 2x2 block per NODE. For each element and each of its
    local nodes a, the local Hessian's own (2x2) sub-block H[2a:2a+2,
    2a:2a+2] -- that node's self-coupling of its x and y equations within
    this one element -- is scatter-added into a global (n_nodes, 2, 2)
    tensor. This captures the u/v (Poisson-ratio-driven) coupling at a node
    that the scalar Jacobi diagonal discards by construction, which is the
    natural next step up in preconditioner quality for a 2-component
    vector-elasticity problem -- still O(DOF) memory and still built from
    nothing bigger than an 8x8 (Q4) or 18x18 (Q9) local Hessian, so it costs
    the same as compute_jacobi_diagonal to build, just with an extra 2x2
    (not 2x1) local extraction per node per element.

    Returns the raw per-node blocks (n_nodes, 2, 2), still in the FULL
    (unconstrained) DOF numbering -- restricting to free_dofs and handling
    nodes where a boundary condition leaves only one of the two DOFs free is
    make_block_jacobi_apply's job, kept separate because that step is pure
    indexing/inversion with no FEM assembly in it."""
    n_nodes = xy.shape[0]
    energy_density_fn, _ = get_material_fns_torch(material)
    shape_data = precompute_shape_data(order, xy.device, dtype)

    Xe_all = xy[quad]
    ue_all = uv_full.reshape(n_nodes, 2)[quad].reshape(Xe_all.shape[0], -1)
    n_local = quad.shape[1]

    local_hess_fn = hessian(_local_element_energy, argnums=0)
    batched_hess = vmap(local_hess_fn, in_dims=(0, 0, 0, None, None, None))

    global_block = torch.zeros(n_nodes, 2, 2, device=xy.device, dtype=dtype)
    n_elem = Xe_all.shape[0]
    for start in range(0, n_elem, chunk_size):
        end = min(start + chunk_size, n_elem)
        elem_params_chunk = tuple(p[start:end] for p in elem_params)
        H_local = batched_hess(ue_all[start:end], Xe_all[start:end], elem_params_chunk,
                                energy_density_fn, shape_data, dtype)  # (chunk, 2nl, 2nl)
        quad_chunk = quad[start:end]  # (chunk, n_local)
        for a in range(n_local):
            block_a = H_local[:, 2 * a:2 * a + 2, 2 * a:2 * a + 2]  # (chunk, 2, 2)
            global_block.index_add_(0, quad_chunk[:, a], block_a)
    return global_block


def make_block_jacobi_apply(global_block, free_dofs, eps=1e-10):
    """Builds the CG apply closure v -> M^-1 v for the 2x2 block-Jacobi
    preconditioner, restricted to the free-DOF subspace.

    A node whose two DOFs (x and y) are BOTH free gets a true 2x2
    block-solve against its own node-local stiffness block. A node with
    only ONE free DOF -- a boundary condition can fix just one component,
    e.g. a symmetry line that fixes u_x but leaves u_y free -- cannot use a
    2x2 solve at all (the other row/column belongs to a DOF that no longer
    exists in the reduced free-DOF system), so it falls back to that single
    scalar diagonal entry: exactly what compute_jacobi_diagonal already
    does for every DOF. A partially-fixed node therefore loses nothing
    relative to plain Jacobi, and a fully-free node gains the true
    node-local 2x2 solve.

    free_dofs is assumed sorted increasing, which every caller in this
    module already guarantees (it is built by filtering range(ndof) in
    order) -- that is what lets pairing be a single vectorized adjacent-diff
    check below instead of a per-node Python loop: two consecutive entries
    of free_dofs are one node's (x, y) pair iff the first is even (an
    x-DOF, i.e. 2*node) and the second equals the first plus one."""
    device = global_block.device
    dtype = global_block.dtype
    n_free = free_dofs.shape[0]
    node_of_free = free_dofs // 2

    is_x = (free_dofs % 2 == 0)
    adjacent = torch.zeros(n_free, dtype=torch.bool, device=device)
    if n_free > 1:
        adjacent[:-1] = (free_dofs[1:] - free_dofs[:-1] == 1)
    pair_start_mask = is_x & adjacent
    pair_start_pos = torch.nonzero(pair_start_mask, as_tuple=False).squeeze(-1)
    has_pairs = pair_start_pos.numel() > 0
    pair_pos = (torch.stack([pair_start_pos, pair_start_pos + 1], dim=1) if has_pairs
                else torch.zeros(0, 2, dtype=torch.long, device=device))

    in_pair = torch.zeros(n_free, dtype=torch.bool, device=device)
    if has_pairs:
        in_pair[pair_pos.reshape(-1)] = True
    singleton_pos = torch.nonzero(~in_pair, as_tuple=False).squeeze(-1)
    has_singletons = singleton_pos.numel() > 0

    if has_pairs:
        pair_nodes = node_of_free[pair_pos[:, 0]]
        blocks = global_block[pair_nodes]  # (n_pairs, 2, 2)
        a, b, c, d = blocks[:, 0, 0], blocks[:, 0, 1], blocks[:, 1, 0], blocks[:, 1, 1]
        det = a * d - b * c
        # Same near-singular guard as compute_jacobi_diagonal, applied per
        # pair: an ill-conditioned 2x2 block falls back to a pure diagonal
        # solve for that one node rather than amplifying the CG direction.
        safe = det.abs() > eps
        a_safe = torch.where(a.abs() > eps, a, torch.ones_like(a))
        d_safe = torch.where(d.abs() > eps, d, torch.ones_like(d))
        inv00 = torch.where(safe, d / det, 1.0 / a_safe)
        inv11 = torch.where(safe, a / det, 1.0 / d_safe)
        inv01 = torch.where(safe, -b / det, torch.zeros_like(a))
        inv10 = torch.where(safe, -c / det, torch.zeros_like(a))

    if has_singletons:
        singleton_nodes = node_of_free[singleton_pos]
        singleton_comp = free_dofs[singleton_pos] % 2
        singleton_diag = global_block[singleton_nodes, singleton_comp, singleton_comp]
        singleton_diag = torch.where(singleton_diag.abs() > eps, singleton_diag,
                                      torch.ones_like(singleton_diag))

    def apply(v):
        out = torch.empty_like(v)
        if has_singletons:
            out[singleton_pos] = v[singleton_pos] / singleton_diag
        if has_pairs:
            vx = v[pair_pos[:, 0]]
            vy = v[pair_pos[:, 1]]
            out[pair_pos[:, 0]] = inv00 * vx + inv01 * vy
            out[pair_pos[:, 1]] = inv10 * vx + inv11 * vy
        return out

    return apply


def _make_energy_fn(xy, quad, n_nodes, material, order, dtype):
    energy_density_fn, _ = get_material_fns_torch(material)
    shape_data = precompute_shape_data(order, xy.device, dtype)
    ndof = 2 * n_nodes

    def energy_fn(u_free, elem_params, free_dofs):
        u_full = torch.zeros(ndof, dtype=dtype, device=u_free.device)
        u_full = u_full.index_copy(0, free_dofs, u_free)
        uv = u_full.reshape(n_nodes, 2)
        return element_energy_order_agnostic(xy, quad, uv, elem_params, energy_density_fn, shape_data, dtype)

    return energy_fn


def matrix_free_hvp(residual_fn, u, v, elem_params, free_dofs):
    """K @ v at point u, without ever forming K: forward-mode differentiate
    the RESIDUAL (already a reverse-mode gradient of the energy) along
    direction v. This is the one step that makes memory cost O(DOF)
    instead of O(DOF^2)."""
    _, Hv = jvp(lambda uu: residual_fn(uu, elem_params, free_dofs), (u,), (v,))
    return Hv


def precompute_local_hessians(xy, quad, u_full, elem_params, material, order, dtype):
    """The local (per-element) tangent Hessian, batched over every element,
    at the CURRENT displacement u_full -- computed ONCE per Newton
    iteration (the same per-Newton-step cost compute_block_jacobi's own
    preconditioner already pays), reused for every CG iteration within
    that Newton step via cached_hessian_hvp below, instead of
    matrix_free_hvp's own forward-over-reverse jvp on every single CG
    iteration.

    WHY THIS IS FASTER, NOT JUST DIFFERENT: within one Newton iteration,
    u (and therefore K(u), the tangent) is FIXED -- only the CG solve's
    own iterate changes. matrix_free_hvp re-differentiates the full
    residual through autodiff on every CG call, redoing work whose
    result (the local Hessian) does not change between CG iterations.
    Precomputing it once and reusing a plain batched matrix-vector
    product per iteration removes that redundant autodiff cost from the
    part of the solve that runs by far the most times (CG iteration
    counts of several thousand per Newton step are typical in this
    project's own published tables).

    Measured directly (2026-09-10, CPU, N=101, B1 x Neo-Hookean, before
    ever integrating this into solve_matrix_free): matrix_free_hvp
    56.4 ms/call vs. this function's one-time cost of 538 ms + 0.87
    ms/call for cached_hessian_hvp thereafter -- a ~65x per-call speedup
    once amortized over more than about a dozen CG iterations (which
    every case in this project's own published tables already exceeds
    by 2-4 orders of magnitude). Verified bit-for-bit equivalent to
    matrix_free_hvp on the same (u, v): relative difference 3.5e-15,
    at the level of floating-point round-off, not an approximation.
    NOT YET benchmarked on GPU -- the ~65x figure is a real, measured
    CPU number, not assumed to transfer to CUDA, where the autodiff
    overhead this removes may be a different fraction of the total
    per-call cost.

    Returns H_local, shape (n_elements, 2*n_local, 2*n_local)."""
    energy_density_fn, _ = get_material_fns_torch(material)
    shape_data = precompute_shape_data(order, xy.device, dtype)
    n_elem, n_local = quad.shape
    Xe_all = xy[quad]
    ue_all = u_full.reshape(-1, 2)[quad].reshape(n_elem, -1)
    local_hess_fn = hessian(_local_element_energy, argnums=0)
    batched_hess = vmap(local_hess_fn, in_dims=(0, 0, 0, None, None, None))
    return batched_hess(ue_all, Xe_all, elem_params, energy_density_fn, shape_data, dtype)


def cached_hessian_hvp(H_local, quad, n_nodes, free_dofs, v_free, dtype, device):
    """K @ v using H_local (precompute_local_hessians' own output) instead
    of re-differentiating -- a batched small (2*n_local x 2*n_local)
    matrix-vector product per element, scatter-added by connectivity,
    the same assembly pattern compute_block_jacobi already uses for its
    own preconditioner, generalized here from extracting diagonal blocks
    to the full local Hessian. free_dofs handling matches matrix_free_
    hvp's own convention: v/Hv live in the FREE-DOF-only space the CG
    solve itself uses."""
    n_elem, n_local = quad.shape
    ndof = 2 * n_nodes
    v_full = torch.zeros(ndof, dtype=dtype, device=device)
    v_full = v_full.index_copy(0, free_dofs, v_free)
    ve_all = v_full.reshape(n_nodes, 2)[quad].reshape(n_elem, -1)
    Hve_all = torch.einsum('eij,ej->ei', H_local, ve_all).reshape(n_elem, n_local, 2)
    Hv_full = torch.zeros(n_nodes, 2, dtype=dtype, device=device)
    Hv_full.index_add_(0, quad.reshape(-1), Hve_all.reshape(-1, 2))
    return Hv_full.reshape(-1)[free_dofs]


def conjugate_gradient(matvec, b, x0, tol, max_iter, precond_diag=None, precond_apply=None,
                        progress_every=None, progress_prefix="",
                        checkpoint_path=None, checkpoint_every=2000):
    """CG for symmetric (K = Hessian of a scalar energy) systems, with an
    optional preconditioner. Two ways to supply one, in increasing order of
    precedence:

    precond_diag: the diagonal of K (see compute_jacobi_diagonal); M^-1 is
    elementwise division by it -- the cheapest preconditioner available,
    but on the heterogeneous-material problems in this study it captures
    exactly the effect (large E in one region making that region's
    equations locally much stiffer) that otherwise drives up CG's
    iteration count.

    precond_apply: a callable v -> M^-1 v, for a preconditioner that isn't
    a pure elementwise scaling -- e.g. make_block_jacobi_apply's 2x2
    node-block solve. If given, this is used and precond_diag is ignored;
    passing neither falls back to unpreconditioned CG (M^-1 = identity),
    exactly as before this parameter existed.

    Returns (x, n_iter, final_residual_norm, converged).

    progress_every: if set, print a heartbeat line (iteration count,
    current relative residual, elapsed time, iters/s) every this many
    iterations -- unconditional on `verbose` in the caller, because at
    ~10M DOF a single CG call can itself run for hours, and with no
    heartbeat there is no way to tell 'still working' from 'stuck' from
    the outside. Cheap: only a norm and a print every progress_every
    iterations, not every iteration.

    checkpoint_path: if given, save this call's own internal state (x, r,
    p, rz_old, iteration count) to this file every checkpoint_every
    iterations, and resume from it if it already exists. A single CG call
    at Q9's ~40M DOF scale can run 10+ hours -- longer than
    solve_matrix_free's own per-Newton-iteration checkpoint can protect
    against by itself, since that only saves once an ENTIRE CG call has
    finished. This bounds a mid-CG disconnect's loss to at most
    checkpoint_every iterations instead of the whole call. b is NOT saved
    -- the caller reconstructs it identically on resume (same u_free, same
    load level), and CG is deterministic given the same (b, starting
    state), so resuming reproduces the exact trajectory an uninterrupted
    call would have taken. The file is deleted the moment this call
    returns, converged or not -- a finished call's state is never
    meaningful to resume into again."""
    def apply_M_inv(v):
        if precond_apply is not None:
            return precond_apply(v)
        return v if precond_diag is None else v / precond_diag

    def save_state(it):
        tmp_path = checkpoint_path + ".tmp"
        torch.save({"x": x.cpu(), "r": r.cpu(), "p": p.cpu(), "rz_old": rz_old, "it": it}, tmp_path)
        os.replace(tmp_path, checkpoint_path)

    def clear_state():
        if checkpoint_path is not None and os.path.exists(checkpoint_path):
            os.remove(checkpoint_path)

    t_start = time.time()
    b_norm = torch.linalg.norm(b) + 1e-30
    start_it = 0

    if checkpoint_path is not None and os.path.exists(checkpoint_path):
        state = torch.load(checkpoint_path, map_location=b.device)
        x = state["x"].to(device=b.device, dtype=b.dtype)
        r = state["r"].to(device=b.device, dtype=b.dtype)
        p = state["p"].to(device=b.device, dtype=b.dtype)
        rz_old = state["rz_old"]
        start_it = state["it"]
        print(f"    {progress_prefix}[CG checkpoint] resuming from iter {start_it}/{max_iter}")
    else:
        x = x0.clone()
        r = b - matvec(x)
        z = apply_M_inv(r)
        p = z.clone()
        rz_old = torch.dot(r, z)
        if torch.linalg.norm(r) / b_norm < tol:
            return x, 0, float(torch.linalg.norm(r)), True

    for it in range(start_it + 1, max_iter + 1):
        Ap = matvec(p)
        alpha = rz_old / (torch.dot(p, Ap) + 1e-30)
        x = x + alpha * p
        r = r - alpha * Ap
        rel_res = torch.linalg.norm(r) / b_norm
        if progress_every and it % progress_every == 0:
            elapsed = time.time() - t_start
            print(f"    {progress_prefix}[CG heartbeat] iter {it}/{max_iter}, "
                  f"rel_res={float(rel_res):.3e} (target {tol:.1e}), "
                  f"elapsed={elapsed:.0f}s, {it/max(elapsed, 1e-9):.1f} it/s")
        if rel_res < tol:
            clear_state()
            return x, it, float(torch.linalg.norm(r)), True
        z = apply_M_inv(r)
        rz_new = torch.dot(r, z)
        p = z + (rz_new / (rz_old + 1e-30)) * p
        rz_old = rz_new
        if checkpoint_path is not None and checkpoint_every and it % checkpoint_every == 0:
            save_state(it)
    clear_state()
    return x, max_iter, float(torch.linalg.norm(r)), False


def solve_matrix_free(xy, quad, free_dofs, elem_params, fext_free_full, n_free,
                       material="neo_hookean", order="Q4", nsteps=10, newton_max=30,
                       newton_tol=1e-7, cg_tol=1e-6, cg_max_iter=2000, use_jacobi=True,
                       precond_kind="jacobi", mg_hierarchy=None,
                       device=None, dtype=torch.float64, verbose=True, checkpoint_path=None,
                       cg_progress_every=None, cg_checkpoint_every=2000,
                       hvp_method="autodiff"):
    """Single-sample (no batch dimension) matrix-free Newton-CG solve.
    elem_params: tuple of (n_elements,) tensors, or (n_elements, n_gauss)
    when the material is sampled per Gauss point as B2's reference solver
    does -- see element_energy_order_agnostic. use_jacobi: recompute a
    preconditioner at the start of every Newton iteration and use it for
    CG -- cheap relative to the CG iterations it is meant to reduce, since
    it only needs small per-element Hessians, never the global one.

    precond_kind selects WHICH preconditioner use_jacobi builds, and only
    matters when use_jacobi=True:
      "jacobi" (default) -- the scalar diagonal of K (compute_jacobi_diagonal).
          This is the exact preconditioner every already-published number in
          this study was produced with; kept as the default so no existing
          result changes unless this argument is passed explicitly.
      "block2x2" -- the 2x2 per-node block-diagonal of K
          (compute_block_jacobi / make_block_jacobi_apply), which also
          captures each node's u/v coupling instead of discarding it. Opt-in
          only: pass precond_kind="block2x2" to use it. Measured (item #4,
          real GPU re-run 2026-09-07) to NOT reduce cg_failures at N=401/701
          relative to plain Jacobi -- kept for reference/comparison, not
          recommended as a fix by itself.
      "mgv" -- a geometric multigrid V-cycle (multigrid_precond.py),
          requires `mg_hierarchy` (a list of multigrid_precond.MGLevel,
          built ONCE by the caller before the Newton loop via
          multigrid_precond.build_mg_hierarchy, from a chain of
          successively coarser meshes of the SAME domain/BCs/material).
          Rebuilding the hierarchy's mesh/material data every Newton
          iteration would be wasted work (only the current nonlinear state
          changes, not the geometry), so only the state-dependent part
          (injected displacement, per-level tangent matvec and Jacobi
          smoother diagonal) is rebuilt here, once per Newton iteration,
          exactly like "jacobi"/"block2x2" already do.
    hvp_method: "autodiff" (default, unchanged from every already-published
    result in this project -- matrix_free_hvp's own forward-over-reverse
    jvp, redone every CG iteration) or "cached_hessian" (precompute_local_
    hessians once per Newton iteration, then cached_hessian_hvp per CG
    iteration -- verified bit-for-bit equivalent, ~65x faster per call on
    CPU at N=101; not yet benchmarked on GPU). Opt-in only, so no existing
    result changes unless this is passed explicitly.

    Returns (u_free, stats).

    checkpoint_path: if given, save (u_free, stats, next step) to this file
    after every completed Newton iteration (not just every completed load
    step), and resume from it if it already exists. At the scale this
    solver now actually runs (Q9 at fine_N=2236, ~40M DOF), a SINGLE Newton
    iteration's CG solve can itself take several hours -- a load step (2
    Newton iterations) can exceed a Colab runtime's own maximum session
    length, so checkpointing only at the load-step boundary (the original
    design, written when a step really was a few minutes of work) could
    lose an entire step's compute to one disconnect. Saving after each
    Newton iteration bounds the loss to at most one in-progress CG solve.
    On top of that, each individual CG call ALSO checkpoints its own
    internal state periodically (see conjugate_gradient's checkpoint_path),
    since one call can itself run 10+ hours -- bounding a mid-CG disconnect
    to at most checkpoint_every CG iterations, not the whole call. Every
    level of resume here is exact (not approximate): reloading state and
    re-entering at the same point reproduces precisely the trajectory an
    uninterrupted run would have taken, since Newton-CG from a warm start
    is deterministic given the same starting point."""
    device = device or xy.device
    n_nodes = xy.shape[0]
    ndof = 2 * n_nodes
    energy_fn = _make_energy_fn(xy, quad, n_nodes, material, order, dtype)
    residual_fn = grad(energy_fn, argnums=0)

    u_free = torch.zeros(n_free, dtype=dtype, device=device)
    stats = {"newton_iters_total": 0, "cg_iters_total": 0, "cg_failures": 0, "load_steps": nsteps,
             # Cost breakdown, the advisor's round-6 request ("The key cost
             # should be the solver while the assembly should be minimal").
             # Three buckets, each bracketed by torch.cuda.synchronize so
             # CUDA's asynchronous dispatch cannot leak between them:
             #   t_residual_s   -- assembling the residual (fint - fext) once
             #                     per Newton iteration
             #   t_precond_s    -- building the Jacobi diagonal, an
             #                     assembly-like pass over all elements
             #   t_cg_s         -- the CG solve itself
             # Note what this cannot separate, and say so rather than
             # pretending otherwise: matrix-free CG never forms K, so every
             # CG iteration is a Hessian-vector product, which IS an
             # assembly-like operation over all elements. t_cg_s is therefore
             # solver time that contains assembly work by construction. The
             # clean assembly-versus-solve split a factorising solver admits
             # does not exist here; gpu_fem_solver.py's profile dict has it
             # because that solver forms K and calls torch.linalg.solve.
             "t_residual_s": 0.0, "t_precond_s": 0.0, "t_cg_s": 0.0}
    start_step = 1

    def _sync():
        if device.type == "cuda":
            torch.cuda.synchronize(device)

    if checkpoint_path is not None and os.path.exists(checkpoint_path):
        ckpt = torch.load(checkpoint_path, map_location=device)
        u_free = ckpt["u_free"].to(device=device, dtype=dtype)
        stats = ckpt["stats"]
        # A checkpoint written before the cost buckets existed has none of
        # them, and += on a missing key raises. Backfill at zero: the
        # resumed run's breakdown then covers only the steps it actually
        # ran, which is the honest reading of a partial timing anyway.
        for _k in ("t_residual_s", "t_precond_s", "t_cg_s"):
            stats.setdefault(_k, 0.0)
        start_step = ckpt["next_step"]
        print(f"  [checkpoint] resuming from {checkpoint_path}: load steps 1-{start_step - 1} "
              f"already done, continuing from step {start_step}/{nsteps}")
        if start_step > nsteps:
            return u_free, stats

    for step in range(start_step, nsteps + 1):
        alpha = step / nsteps
        fext_free = alpha * fext_free_full
        for it in range(1, newton_max + 1):
            _sync(); _t0 = time.time()
            R = residual_fn(u_free, elem_params, free_dofs) - fext_free
            res_norm = torch.linalg.norm(R)
            _sync(); stats["t_residual_s"] += time.time() - _t0
            if res_norm < newton_tol:
                break
            stats["newton_iters_total"] += 1
            if cg_progress_every:
                print(f"  [step {step}/{nsteps}] Newton iter {it}: ||R||={float(res_norm):.3e} "
                      f"(target {newton_tol:.1e}) -- starting CG solve...")
            t_cg = time.time()

            if hvp_method == "cached_hessian":
                _sync(); _t0 = time.time()
                u_full_for_hvp = torch.zeros(ndof, dtype=dtype, device=device).index_copy(
                    0, free_dofs, u_free)
                H_local = precompute_local_hessians(xy, quad, u_full_for_hvp, elem_params,
                                                     material, order, dtype)
                _sync(); stats["t_hvp_setup_s"] = stats.get("t_hvp_setup_s", 0.0) + time.time() - _t0

                def matvec(v):
                    return cached_hessian_hvp(H_local, quad, n_nodes, free_dofs, v, dtype, device)
            elif hvp_method == "autodiff":
                def matvec(v):
                    return matrix_free_hvp(residual_fn, u_free, v, elem_params, free_dofs)
            else:
                raise ValueError(f"unknown hvp_method {hvp_method!r}, expected 'autodiff' or "
                                  "'cached_hessian'")

            precond_diag = None
            precond_apply = None
            if use_jacobi:
                _sync(); _t0 = time.time()
                u_full = torch.zeros(ndof, dtype=dtype, device=device).index_copy(0, free_dofs, u_free)
                if precond_kind == "block2x2":
                    global_block = compute_block_jacobi(xy, quad, u_full, elem_params, material, order, dtype)
                    precond_apply = make_block_jacobi_apply(global_block, free_dofs)
                elif precond_kind == "jacobi":
                    precond_diag = compute_jacobi_diagonal(xy, quad, u_full, elem_params, material, order,
                                                            dtype, free_dofs)
                elif precond_kind == "mgv":
                    if mg_hierarchy is None:
                        raise ValueError("precond_kind='mgv' requires mg_hierarchy "
                                         "(see multigrid_precond.build_mg_hierarchy)")
                    from omar_pfem.multigrid_precond import build_mg_precond_apply
                    precond_apply = build_mg_precond_apply(mg_hierarchy, u_full, material, order)
                else:
                    raise ValueError(f"unknown precond_kind {precond_kind!r}, "
                                     "expected 'jacobi', 'block2x2', or 'mgv'")
                _sync(); stats["t_precond_s"] += time.time() - _t0

            cg_checkpoint_path = f"{checkpoint_path}.cg_state" if checkpoint_path is not None else None
            _sync(); _t0 = time.time()
            delta, cg_iters, cg_res, cg_converged = conjugate_gradient(
                matvec, -R, torch.zeros_like(u_free), cg_tol, cg_max_iter,
                precond_diag=precond_diag, precond_apply=precond_apply,
                progress_every=cg_progress_every, progress_prefix=f"step {step}/{nsteps} newton {it}: ",
                checkpoint_path=cg_checkpoint_path, checkpoint_every=cg_checkpoint_every)
            _sync(); stats["t_cg_s"] += time.time() - _t0
            stats["cg_iters_total"] += cg_iters
            if cg_progress_every:
                print(f"    CG done: {cg_iters} iters in {time.time() - t_cg:.0f}s, "
                      f"converged={cg_converged}, final residual={cg_res:.3e}")
            if not cg_converged:
                stats["cg_failures"] += 1
                if verbose or cg_progress_every:
                    print(f"  [WARNING] CG did not converge at step {step}, Newton iter {it} "
                          f"(residual {cg_res:.3e} after {cg_iters} iters)")
            u_free = u_free + delta

            if checkpoint_path is not None:
                # Mid-step checkpoint: next_step=step (not step+1) means "this
                # step isn't done yet, but resume here with this improved
                # u_free" -- the existing resume path already re-enters the
                # Newton loop for `step` unchanged, so no extra state (which
                # Newton iteration we were on) needs to be tracked separately.
                tmp_path = checkpoint_path + ".tmp"
                torch.save({"u_free": u_free.cpu(), "stats": stats, "next_step": step}, tmp_path)
                os.replace(tmp_path, checkpoint_path)
                print(f"  [checkpoint] saved after step {step}/{nsteps} Newton iter {it} "
                      f"(step not yet complete) -> {checkpoint_path}")

            if (verbose or cg_progress_every) and it == newton_max:
                print(f"  [step {step}/{nsteps}] Newton did NOT converge, ||R||={res_norm:.3e}")
        if verbose:
            print(f"  [step {step}/{nsteps}] converged, ||R||={res_norm:.3e} "
                  f"(cumulative CG iters so far: {stats['cg_iters_total']})")

        if checkpoint_path is not None:
            tmp_path = checkpoint_path + ".tmp"
            torch.save({"u_free": u_free.cpu(), "stats": stats, "next_step": step + 1}, tmp_path)
            os.replace(tmp_path, checkpoint_path)  # atomic -- never leaves a half-written checkpoint
            print(f"  [checkpoint] saved after step {step}/{nsteps} -> {checkpoint_path}")

    return u_free, stats
