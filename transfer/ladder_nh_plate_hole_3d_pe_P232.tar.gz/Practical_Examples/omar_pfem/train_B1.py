"""
Training script for the B1 benchmark (unit square, top-edge traction, fixed
bottom edge) using the PFEM/Transolver pipeline -- adapted from PFEM-main's
practical_problems/Hyper_beam/exp_hyper_PINO_transolver_quad.py (Yizheng
Wang et al., "Pretrain finite element method", JMPS 2026).

Unchanged from the beam example: the Q4 isoparametric shape functions, the
2x2-Gauss "explicit differentiation" energy computation (element strain
gradients via shape-function derivatives contracted with the network's
predicted nodal displacements, not autodiff), the total-potential-energy
(Pi = U - W) loss with no other loss term, and the Transolver
architecture/training-loop structure.

Swapped for B1's geometry: the beam fixes the LEFT edge (x=0) and loads the
RIGHT edge (x=Lx) with a y-varying traction (cantilever); B1 fixes the
BOTTOM edge (y=0) and loads the TOP edge (y=Ly) with an x-varying traction.
The hard-Dirichlet ramp and the boundary dataset fields (top_edges /
bottom_nodes vs. right_edges / left_nodes) are updated accordingly.

Extended beyond PFEM-main (which only implements Neo-Hookean): the strain
energy density is now selected via --material {neo_hookean,mooney_rivlin,
arruda_boyce}, dispatched through omar_pfem/materials_torch.py's registry
so training always uses the same constitutive law as the FEM ground-truth
dataset it is trained/evaluated against.
"""
import os
import re
import glob
import time
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
import json
import random

from omar_pfem.model_dict import get_model
from omar_pfem.materials_torch import get_material_fns


def find_latest_checkpoint(out_dir):
    """Epoch-level resume: a case at 10000 epochs / ntrain~800 can run for
    hours, so a mid-case disconnect shouldn't discard all of it -- if a
    prior run already wrote model_epoch{N}.pt files, pick up training from
    the highest N instead of starting over. Optimizer momentum state is not
    preserved (only model weights), a deliberate, acceptable simplification
    given how infrequently save_every fires relative to total epochs."""
    ckpts = glob.glob(os.path.join(out_dir, "model_epoch*.pt"))
    if not ckpts:
        return None, 0

    def _epoch_num(p):
        m = re.search(r"model_epoch(\d+)\.pt$", os.path.basename(p))
        return int(m.group(1)) if m else -1

    latest = max(ckpts, key=_epoch_num)
    return latest, _epoch_num(latest)


# ============================================================
# 0) Utility: quad -> tri (for plotting only)
# ============================================================
def quad_to_tri(quad):
    q = quad
    t1 = np.stack([q[:, 0], q[:, 1], q[:, 2]], axis=1)
    t2 = np.stack([q[:, 0], q[:, 2], q[:, 3]], axis=1)
    tri = np.concatenate([t1, t2], axis=0)
    return tri


# ============================================================
# 2) Q4 shape functions on [-1,1]^2 -- unchanged from PFEM
# ============================================================
def shape_Q4_torch(xi, eta, device, dtype):
    N = 0.25 * torch.tensor([
        (1 - xi) * (1 - eta),
        (1 + xi) * (1 - eta),
        (1 + xi) * (1 + eta),
        (1 - xi) * (1 + eta),
    ], device=device, dtype=dtype)

    dN_dxi = 0.25 * torch.tensor([
        [-(1 - eta), -(1 - xi)],
        [+(1 - eta), -(1 + xi)],
        [+(1 + eta), +(1 + xi)],
        [-(1 + eta), +(1 - xi)],
    ], device=device, dtype=dtype)
    return N, dN_dxi


# ============================================================
# 3) Hyperelastic energy on Q4 mesh (TL, 2x2 Gauss) -- unchanged from PFEM,
#    generalized to dispatch across any material's energy density
# ============================================================
def compute_hyperelastic_energy_Q4(xy, quad, uv, param_nodes, energy_density_fn, dtype=torch.float32):
    """Batched version: uv is (B,N,2), each entry of param_nodes is (B,N).
    B=1 (a single sample with a leading batch dim) reproduces the original
    per-sample computation exactly.

    Reference-configuration quantities (J0, detJ0, dN_dX) depend only on
    the mesh (xy, quad), not on the batch's displacement field, since all
    samples in a case share the same mesh -- so they're computed ONCE per
    Gauss point and reused across the whole batch, instead of once per
    sample as a naive per-sample loop would do. This is what makes real
    batching (as opposed to gradient accumulation) actually cheaper per
    sample, not just fewer optimizer steps.

    param_nodes: tuple of per-node parameter tensors (length/meaning
    depends on the material, e.g. (mu, lam) for Neo-Hookean or
    (c, c1, c2, d) for Mooney-Rivlin), each averaged per-element the same
    way and passed positionally to energy_density_fn(F, *params_e, dtype=)."""
    device = xy.device
    B = uv.shape[0]
    Q = quad.shape[0]

    Xe = xy[quad]           # (Q,4,2) -- shared across the batch
    ue = uv[:, quad]        # (B,Q,4,2)

    g = 1.0 / np.sqrt(3.0)
    gps = [(-g, -g), (g, -g), (g, g), (-g, g)]
    w = 1.0

    U = torch.zeros(B, device=device, dtype=dtype)
    F_list = []

    for (xi, eta) in gps:
        xi_t = torch.tensor(float(xi), device=device, dtype=dtype)
        eta_t = torch.tensor(float(eta), device=device, dtype=dtype)
        N, dN_dxi = shape_Q4_torch(xi_t, eta_t, device, dtype)

        J0 = torch.einsum("qai,aj->qij", Xe, dN_dxi)

        detJ0 = J0[:, 0, 0] * J0[:, 1, 1] - J0[:, 0, 1] * J0[:, 1, 0]
        detJ0 = torch.clamp(detJ0, min=1e-12)

        invJ0 = torch.zeros_like(J0)
        invJ0[:, 0, 0] = J0[:, 1, 1] / detJ0
        invJ0[:, 1, 1] = J0[:, 0, 0] / detJ0
        invJ0[:, 0, 1] = -J0[:, 0, 1] / detJ0
        invJ0[:, 1, 0] = -J0[:, 1, 0] / detJ0

        dN_dX = torch.einsum("aj,qjk->qak", dN_dxi, invJ0)

        grad_u = torch.einsum("bqai,qaj->bqij", ue, dN_dX)

        I = torch.eye(2, device=device, dtype=dtype).reshape(1, 1, 2, 2).expand(B, Q, 2, 2)
        F = I + grad_u  # (B,Q,2,2)

        params_e = tuple(torch.mean(p[:, quad], dim=2) for p in param_nodes)  # each (B,Q)

        F_flat = F.reshape(B * Q, 2, 2)
        params_e_flat = tuple(p.reshape(B * Q) for p in params_e)
        psi = energy_density_fn(F_flat, *params_e_flat, dtype=dtype).reshape(B, Q)
        U = U + torch.sum(psi * detJ0[None, :] * w, dim=1)

        F_list.append(F.detach().reshape(B * Q, 2, 2))

    F_g = torch.cat(F_list, dim=0)
    return U, F_g


# ============================================================
# 3b) Input-channel normalization (advisor round-6, point 1)
# ============================================================
# Timon asked, once the OOD degradation was attributed to a factor, that a
# "relatively straightforward mitigation, such as changing the training range
# or normalization" be TESTED rather than only proposed. Section 8.6 named
# normalizing the E channel as the cheapest candidate. This is that knob.
#
# Why it is a module-level global rather than an argument: the network's
# inputs are assembled in exactly two places (the energy/training path and the
# inference path, both below), but they are CALLED from many -- the zero-shot
# study, the Pareto analysis, ood_progressive, the latency benchmark -- each
# through its own wrapper. Threading a new argument through all of them is how
# a train/eval mismatch gets created: one call site is missed, the model is
# evaluated on inputs scaled differently from the ones it trained on, and the
# resulting number looks like a research finding instead of a bug. A single
# global that every path reads makes that mismatch impossible.
#
# The statistics are FIXED CONSTANTS measured once on the training set and
# stored with the checkpoint. They are never recomputed per batch or per
# sample. That distinction is the whole experiment: standardizing by the
# batch's own statistics would silently re-center a shifted distribution back
# onto the training one and report a fake immunity to distribution shift.
_INPUT_NORM = None


def set_input_norm(stats):
    """Install (or clear, with None) the input normalization. `stats` is a
    dict with 'mean' and 'std', each a list of `fun_dim` floats ordered as the
    channels are stacked below: E, nu, [fx,] fy."""
    global _INPUT_NORM
    if stats is None:
        _INPUT_NORM = None
        return
    mean, std = list(stats["mean"]), list(stats["std"])
    assert len(mean) == len(std), "input-norm mean and std differ in length"
    assert all(s > 0 for s in std), f"input-norm has a non-positive std: {std}"
    _INPUT_NORM = {"mean": mean, "std": std}


def get_input_norm():
    return None if _INPUT_NORM is None else dict(_INPUT_NORM)


def install_input_norm_for_checkpoint(ckpt_path, required=None):
    """Install the normalization belonging to a checkpoint, by looking for
    input_norm.json beside it. Every evaluation script that loads a checkpoint
    should call this: a model trained on standardized inputs and evaluated on
    raw ones produces plausible-looking garbage rather than an error.

    `required=True` fails if no statistics are found, `required=False` fails if
    some are, `None` accepts either. Returns the stats, or None."""
    import json as _json
    d = ckpt_path if os.path.isdir(ckpt_path) else os.path.dirname(ckpt_path)
    p = os.path.join(d, "input_norm.json")
    if os.path.exists(p):
        with open(p) as f:
            stats = _json.load(f)
        if required is False:
            raise RuntimeError(
                f"{p} exists, so this checkpoint was trained on standardized "
                f"inputs, but the caller asked for an unnormalized model")
        set_input_norm(stats)
        print(f"[input-norm] loaded {p}: mean={stats['mean']} std={stats['std']}")
        return stats
    if required is True:
        raise FileNotFoundError(
            f"no input_norm.json beside {ckpt_path}; this checkpoint was not "
            f"trained with --normalize_inputs 1")
    set_input_norm(None)
    return None


def _apply_input_norm(fun_material):
    """Standardize each input channel by the stored training-set statistics.
    A no-op when no statistics are installed, which is the default and is what
    every result in the report to date was produced under."""
    if _INPUT_NORM is None:
        return fun_material
    C = fun_material.shape[-1]
    assert len(_INPUT_NORM["mean"]) == C, (
        f"input norm has {len(_INPUT_NORM['mean'])} channels but the model is "
        f"being fed {C}; the checkpoint's input_norm.json does not match "
        f"--fun_dim")
    mean = torch.tensor(_INPUT_NORM["mean"], device=fun_material.device,
                        dtype=fun_material.dtype)
    std = torch.tensor(_INPUT_NORM["std"], device=fun_material.device,
                       dtype=fun_material.dtype)
    return (fun_material - mean) / std


def compute_input_norm(samples, fun_dim):
    """Per-channel mean and std over every node of every training sample.

    The force channels are computed over ALL nodes, loaded and unloaded alike,
    because that is exactly what the network is fed: node_forces is zero on
    every interior node, and those zeros are part of the input distribution.
    Restricting the statistics to loaded nodes would standardize the input by
    something the network never sees on its own."""
    E = np.concatenate([s["E_node"].ravel() for s in samples])
    nu = np.concatenate([s["nu_node"].ravel() for s in samples])
    f = np.concatenate([s["node_forces"].reshape(-1, 2) for s in samples], axis=0)
    cols = [E, nu, f[:, 1]] if fun_dim == 3 else [E, nu, f[:, 0], f[:, 1]]
    names = ["E", "nu", "fy"] if fun_dim == 3 else ["E", "nu", "fx", "fy"]
    mean = [float(c.mean()) for c in cols]
    std = [float(c.std()) for c in cols]

    # A constant channel cannot be standardized -- there is no scale to divide
    # by. This is not hypothetical: on B1 the traction is purely vertical
    # (data_generate_B1.assemble_traction_top_spatial builds t = [0, ty]), so
    # with fun_dim=4 the fx channel is identically zero at every node of every
    # sample, and the network is being fed a channel that carries no
    # information at all. Such a channel is passed through untouched (mean 0,
    # std 1) rather than raising: it is a property of the geometry, not an
    # error, and zero is already a perfectly well-scaled input.
    constant = []
    for i, s in enumerate(std):
        if s <= 1e-12 * max(1.0, abs(mean[i])):
            constant.append(names[i])
            mean[i], std[i] = 0.0, 1.0
    return {"mean": mean, "std": std, "n_samples": len(samples),
            "n_values_per_channel": int(len(E)), "fun_dim": int(fun_dim),
            "channels": names, "constant_channels_passed_through": constant}


# ============================================================
# 4) Total potential energy Pi = U - W  (Q4 version, B1 geometry)
# ============================================================
def total_potential_energy_Q4_hyperelastic(
    xy, quad, top_edges, bottom_nodes,
    model, E_nodes, nu_nodes, node_forces,
    use_soft_dirichlet=True,
    Ly=1.0,
    mode="plane_strain",
    dtype=torch.float32,
    fun_dim=4,
    material="neo_hookean",
):
    """Batched: E_nodes, nu_nodes are (B,N); node_forces is (B,N,2). All
    batch items share the same mesh (xy, quad, top_edges, bottom_nodes),
    since B1's geometry is fixed across samples -- only material/force
    fields vary. Returns per-sample Pi, U, W of shape (B,) and uv (B,N,2).
    A caller with a single sample just passes tensors with a leading
    dimension of 1 (see the *_single wrappers below), which reproduces the
    original per-sample behavior exactly."""
    device = xy.device
    B = E_nodes.shape[0]
    N = xy.shape[0]

    xy_domain = xy.unsqueeze(0).expand(B, N, 2)  # (B,N,2)

    if fun_dim == 3:
        fun_material = torch.stack([
            E_nodes, nu_nodes, node_forces[:, :, 1],
        ], dim=2)
    else:
        fun_material = torch.stack([
            E_nodes, nu_nodes, node_forces[:, :, 0], node_forces[:, :, 1],
        ], dim=2)
    fun_material = _apply_input_norm(fun_material)

    uv_raw = model(xy_domain, fun_material)  # (B,N,2)

    # ---- Dirichlet: bottom edge (y=0) fixed -- ramp grows with y instead of x
    if use_soft_dirichlet:
        free = (xy[:, 1] / Ly).clamp(0.0, 1.0)
    else:
        free = torch.ones(N, device=device, dtype=dtype)
        if bottom_nodes.numel() > 0:
            free[bottom_nodes] = 0.0
    uv = uv_raw * free[None, :, None]

    energy_density_fn, E_nu_to_params_fn = get_material_fns(material)
    if material == "neo_hookean":
        param_nodes = E_nu_to_params_fn(E_nodes, nu_nodes, mode=mode)
    else:
        param_nodes = E_nu_to_params_fn(E_nodes, nu_nodes)

    U, Fg = compute_hyperelastic_energy_Q4(xy, quad, uv, param_nodes, energy_density_fn, dtype=dtype)

    W = torch.sum(node_forces * uv, dim=(1, 2)) / len(top_edges)

    Pi = U - W
    return Pi, U.detach(), W.detach(), uv, Fg


@torch.no_grad()
def predict_displacement_Q4_only(
    xy, quad, top_edges, bottom_nodes,
    model, E_nodes, nu_nodes, node_forces,
    use_soft_dirichlet=True,
    Ly=1.0,
    dtype=torch.float32,
    fun_dim=4,
):
    """Deployment-time inference: the network forward pass plus the
    Dirichlet ramp, with none of the Gauss-quadrature energy assembly of
    total_potential_energy_Q4_hyperelastic (U, Fg) -- that assembly exists
    only to form the training loss and is never needed to predict a new
    sample's displacement field once the network is trained. Used for the
    inference-latency benchmark (see benchmark_inference_latency_Q4)."""
    device = xy.device
    B = E_nodes.shape[0]
    N = xy.shape[0]
    xy_domain = xy.unsqueeze(0).expand(B, N, 2)

    if fun_dim == 3:
        fun_material = torch.stack([E_nodes, nu_nodes, node_forces[:, :, 1]], dim=2)
    else:
        fun_material = torch.stack([E_nodes, nu_nodes, node_forces[:, :, 0], node_forces[:, :, 1]], dim=2)
    fun_material = _apply_input_norm(fun_material)

    uv_raw = model(xy_domain, fun_material)

    if use_soft_dirichlet:
        free = (xy[:, 1] / Ly).clamp(0.0, 1.0)
    else:
        free = torch.ones(N, device=device, dtype=dtype)
        if bottom_nodes.numel() > 0:
            free[bottom_nodes] = 0.0
    return uv_raw * free[None, :, None]


def benchmark_inference_latency_Q4(samples, model, args, device, dtype, n_repeats=200, n_warmup=20):
    """Pure inference latency: one new sample at a time (batch_size=1, the
    realistic deployment scenario -- new instances arrive one at a time,
    not in a pre-assembled batch), forward pass only (predict_displacement_Q4_only,
    no backward pass, no optimizer step, no energy assembly). Reports
    milliseconds per sample, averaged over n_repeats calls after n_warmup
    untimed warm-up calls (to exclude one-off CUDA/cuDNN initialization
    cost from the measurement)."""
    model.eval()
    s0 = samples[0]
    xy = torch.tensor(s0["xy"], device=device, dtype=dtype)
    quad = torch.tensor(s0["quad"], device=device, dtype=torch.long)
    top_edges = torch.tensor(s0["top_edges"], device=device, dtype=torch.long)
    bottom_nodes = torch.tensor(s0["bottom_nodes"], device=device, dtype=torch.long)
    E1 = torch.tensor(s0["E_node"], device=device, dtype=dtype).unsqueeze(0)
    nu1 = torch.tensor(s0["nu_node"], device=device, dtype=dtype).unsqueeze(0)
    f1 = torch.tensor(s0["node_forces"], device=device, dtype=dtype).unsqueeze(0)

    def _one_call():
        return predict_displacement_Q4_only(
            xy, quad, top_edges, bottom_nodes, model, E1, nu1, f1,
            use_soft_dirichlet=args.use_soft_dirichlet, Ly=args.Ly,
            dtype=dtype, fun_dim=args.fun_dim,
        )

    for _ in range(n_warmup):
        _one_call()
    if device.type == "cuda":
        torch.cuda.synchronize(device)

    t0 = time.time()
    for _ in range(n_repeats):
        _one_call()
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elapsed_s = time.time() - t0

    ms_per_sample = 1000.0 * elapsed_s / n_repeats
    return {
        "inference_ms_per_sample": ms_per_sample,
        "inference_n_repeats": n_repeats,
        "inference_batch_size": 1,
        "inference_device": device.type,
    }


def total_potential_energy_Q4_hyperelastic_single(
    xy, quad, top_edges, bottom_nodes,
    model, E_nodes, nu_nodes, node_forces,
    use_soft_dirichlet=True,
    Ly=1.0,
    mode="plane_strain",
    dtype=torch.float32,
    fun_dim=4,
    material="neo_hookean",
):
    """Single-sample convenience wrapper (used by eval/visualization/
    dataset-preview code, where processing one sample at a time is
    simpler and the extra batching overhead doesn't matter): adds/removes
    the leading batch dimension of size 1 around the batched function."""
    Pi, U, W, uv, Fg = total_potential_energy_Q4_hyperelastic(
        xy, quad, top_edges, bottom_nodes,
        model, E_nodes.unsqueeze(0), nu_nodes.unsqueeze(0), node_forces.unsqueeze(0),
        use_soft_dirichlet=use_soft_dirichlet, Ly=Ly, mode=mode, dtype=dtype,
        fun_dim=fun_dim, material=material,
    )
    return Pi[0], U[0], W[0], uv[0], Fg


# ============================================================
# 5) Visualization helpers (Q4)
# ============================================================
def plot_mesh_with_materials_and_forces_q4(samples, args, sid=0, tag="mesh_material_force_check"):
    os.makedirs(args.out_dir, exist_ok=True)

    s = samples[sid]
    xy = s["xy"]
    quad = s["quad"]
    bottom_nodes = s["bottom_nodes"]
    top_edges = s["top_edges"]
    E_node = s.get("E_node", None)
    nu_node = s.get("nu_node", None)
    node_forces = s.get("node_forces", None)

    x = xy[:, 0]
    y = xy[:, 1]

    bottom_mask = np.zeros(x.shape[0], dtype=bool)
    if bottom_nodes is not None and len(bottom_nodes) > 0:
        bottom_mask[bottom_nodes] = True

    tri = quad_to_tri(quad)

    fig, axes = plt.subplots(2, 3, figsize=(18, 12))

    ax = axes[0, 0]
    ax.triplot(x, y, tri, linewidth=0.3, color='gray', alpha=0.5)
    ax.scatter(x, y, s=6, c="k", alpha=0.7)
    if bottom_mask.any():
        ax.scatter(x[bottom_mask], y[bottom_mask], s=18, c="lime", label="Fixed (y=0)")
    if top_edges is not None and top_edges.shape[0] > 0:
        for (i, j) in top_edges:
            ax.plot([x[i], x[j]], [y[i], y[j]], "r-", linewidth=1.5)
        ax.plot([], [], "r-", linewidth=1.5, label="Traction edges")
    ax.set_aspect("equal")
    ax.set_title(f"Q4 Mesh - sid={sid}")
    ax.set_xlabel("x"); ax.set_ylabel("y")
    ax.legend(loc="best")

    if E_node is not None:
        ax = axes[0, 1]
        sc = ax.scatter(x, y, c=E_node, s=10, cmap="viridis")
        ax.set_aspect("equal")
        ax.set_title(f"E Distribution\nMean={E_node.mean():.1f}, Std={E_node.std():.1f}")
        plt.colorbar(sc, ax=ax)

    if node_forces is not None:
        ax = axes[0, 2]
        fm = np.sqrt(node_forces[:, 0]**2 + node_forces[:, 1]**2)
        mask = fm > 0
        if np.any(mask):
            sc = ax.scatter(x[mask], y[mask], c=fm[mask], s=30, cmap="hot", alpha=0.8)
            ax.set_aspect("equal")
            ax.set_title(f"Force |f|\nMean={fm[mask].mean():.3f}")
            plt.colorbar(sc, ax=ax)
        else:
            ax.set_aspect("equal")
            ax.set_title("No force applied")

    if E_node is not None:
        ax = axes[1, 0]
        ax.hist(E_node, bins=30, alpha=0.7, edgecolor="black")
        ax.set_title("E Histogram")

    if nu_node is not None:
        ax = axes[1, 1]
        ax.hist(nu_node, bins=30, alpha=0.7, edgecolor="black")
        ax.set_title("nu Histogram")

    ax = axes[1, 2]
    if node_forces is not None:
        fm = np.sqrt(node_forces[:, 0]**2 + node_forces[:, 1]**2)
        nz = fm[fm > 0]
        if len(nz) > 0:
            ax.hist(nz, bins=30, alpha=0.7, edgecolor="black")
            ax.set_title(f"Force |f| Histogram\nMean={nz.mean():.3f}")
        else:
            ax.set_title("No force applied")
    else:
        ax.set_title("No force field")

    plt.tight_layout()
    plt.savefig(os.path.join(args.out_dir, f"mesh_materials_forces_{tag}_sid{sid}.png"), dpi=300)
    plt.close()
    print(f"[Saved] mesh_materials_forces_{tag}_sid{sid}.png in {args.out_dir}")


# ============================================================
# 6) Dataset loader (Q4 NPZ, B1 fields)
# ============================================================
def _as_dict(obj):
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "item"):
        try:
            return obj.item()
        except Exception:
            pass
    return obj


def load_fem_dataset_Q4_with_materials_and_random_force(path, ntrain, ntest):
    """
    Expect NPZ fields (Q4, B1 geometry):
      coord, quad, disp2D, top_edges, bottom_nodes, E_node, nu_node, boundary_info
    boundary_info: dict with keys node_indices, force_vectors, coordinates
    """
    data = np.load(path, allow_pickle=True)

    coords = data["coord"]
    quads = data["quad"]
    disp2Ds = data["disp2D"]
    top_edges_list = data["top_edges"]
    bottom_nodes_list = data["bottom_nodes"]
    E_nodes_list = data["E_node"]
    nu_nodes_list = data["nu_node"]
    boundary_info_list = data["boundary_info"]

    N = len(coords)
    assert ntrain + ntest <= N, f"ntrain+ntest={ntrain+ntest} exceeds dataset size N={N}"

    def build_sample(i):
        binfo = _as_dict(boundary_info_list[i])
        boundary_nodes = np.array(binfo["node_indices"], dtype=np.int64)
        boundary_forces = np.array(binfo["force_vectors"], dtype=np.float32)
        boundary_coords = np.array(binfo["coordinates"], dtype=np.float32)

        n_nodes = len(coords[i])
        node_forces = np.zeros((n_nodes, 2), dtype=np.float32)
        if len(boundary_nodes) > 0:
            node_forces[boundary_nodes] = boundary_forces

        return {
            "gid": int(i),
            "xy": coords[i].astype(np.float32),
            "quad": quads[i].astype(np.int64),
            "uv_exact": disp2Ds[i].astype(np.float32),
            "top_edges": top_edges_list[i].astype(np.int64),
            "bottom_nodes": bottom_nodes_list[i].astype(np.int64),
            "E_node": E_nodes_list[i].astype(np.float32),
            "nu_node": nu_nodes_list[i].astype(np.float32),
            "node_forces": node_forces,
            "boundary_nodes": boundary_nodes,
            "boundary_forces": boundary_forces,
            "boundary_coords": boundary_coords,
        }

    Train_samples = [build_sample(i) for i in range(ntrain)]
    Test_samples = [build_sample(ntrain + i) for i in range(ntest)]

    # ntrain=0 is a legitimate call pattern for evaluation-only use (e.g.
    # evaluate_ood.py loading a test-only split from an already-trained
    # checkpoint, no training happening) -- skip the training-set stats
    # print instead of crashing on an empty concatenate.
    if Train_samples:
        print("\nMaterial statistics in training set:")
        all_E = np.concatenate([s["E_node"] for s in Train_samples], axis=0)
        all_nu = np.concatenate([s["nu_node"] for s in Train_samples], axis=0)
        print(f"  E: mean={all_E.mean():.2f}, std={all_E.std():.2f}, min={all_E.min():.2f}, max={all_E.max():.2f}")
        print(f"  nu: mean={all_nu.mean():.4f}, std={all_nu.std():.4f}, min={all_nu.min():.4f}, max={all_nu.max():.4f}")

        print("\nForce statistics in training set:")
        all_forces = np.concatenate([s["node_forces"] for s in Train_samples], axis=0)
        fm = np.sqrt(all_forces[:, 0]**2 + all_forces[:, 1]**2)
        nz = fm[fm > 0]
        if len(nz) > 0:
            print(f"  Force: mean={nz.mean():.3f}, std={nz.std():.3f}, min={nz.min():.3f}, max={nz.max():.3f}")
            print(f"  Nodes with force: {len(nz)} / {len(fm)}")
        else:
            print("  No nonzero forces found.")

    return Train_samples, Test_samples


# ============================================================
# 7) Eval + Viz (Q4)
# ============================================================
@torch.no_grad()
def evaluate_dataset_hyperelastic_Q4(samples, model, args, device, dtype, eval_batch_size=32):
    """Batched evaluation: all samples in a case share the same mesh, so
    the whole test set is processed in chunks of eval_batch_size (one
    forward pass each) instead of one sample at a time -- this matters
    once validation runs every 25-50 epochs instead of every 250-500."""
    model.eval()
    rel_l2_u_list, rel_l2_v_list = [], []
    E_mean_list, nu_mean_list, f_mean_list = [], [], []

    if len(samples) == 0:
        return {
            "mean_rel_L2_u": 0.0, "mean_rel_L2_v": 0.0,
            "std_rel_L2_u": 0.0, "std_rel_L2_v": 0.0,
            "mean_E": 0.0, "mean_nu": 0.0, "mean_force": 0.0,
        }

    s0 = samples[0]
    xy = torch.tensor(s0["xy"], device=device, dtype=dtype)
    quad = torch.tensor(s0["quad"], device=device, dtype=torch.long)
    top_edges = torch.tensor(s0["top_edges"], device=device, dtype=torch.long)
    bottom_nodes = torch.tensor(s0["bottom_nodes"], device=device, dtype=torch.long)

    n = len(samples)
    for start in range(0, n, eval_batch_size):
        chunk = samples[start:start + eval_batch_size]
        E_batch = torch.tensor(np.stack([c["E_node"] for c in chunk]), device=device, dtype=dtype)
        nu_batch = torch.tensor(np.stack([c["nu_node"] for c in chunk]), device=device, dtype=dtype)
        force_batch = torch.tensor(np.stack([c["node_forces"] for c in chunk]), device=device, dtype=dtype)
        uv_exact_batch = torch.tensor(np.stack([c["uv_exact"] for c in chunk]), device=device, dtype=dtype)

        _, _, _, uv_pred_batch, _ = total_potential_energy_Q4_hyperelastic(
            xy, quad, top_edges, bottom_nodes,
            model, E_batch, nu_batch, force_batch,
            use_soft_dirichlet=args.use_soft_dirichlet,
            Ly=args.Ly,
            mode=args.mode,
            dtype=dtype,
            fun_dim=args.fun_dim,
            material=args.material,
        )

        err = uv_pred_batch - uv_exact_batch
        l2_u = torch.sqrt(torch.mean(err[:, :, 0] ** 2, dim=1))
        l2_v = torch.sqrt(torch.mean(err[:, :, 1] ** 2, dim=1))
        ref_u = torch.sqrt(torch.mean(uv_exact_batch[:, :, 0] ** 2, dim=1)) + 1e-12
        ref_v = torch.sqrt(torch.mean(uv_exact_batch[:, :, 1] ** 2, dim=1)) + 1e-12

        rel_l2_u_list.extend((l2_u / ref_u).tolist())
        rel_l2_v_list.extend((l2_v / ref_v).tolist())
        E_mean_list.extend(E_batch.mean(dim=1).tolist())
        nu_mean_list.extend(nu_batch.mean(dim=1).tolist())

        fm = torch.sqrt(torch.sum(force_batch ** 2, dim=2))
        for i in range(fm.shape[0]):
            nz = fm[i][fm[i] > 0]
            if len(nz) > 0:
                f_mean_list.append(nz.mean().item())

    return {
        "mean_rel_L2_u": float(np.mean(rel_l2_u_list)) if rel_l2_u_list else 0.0,
        "mean_rel_L2_v": float(np.mean(rel_l2_v_list)) if rel_l2_v_list else 0.0,
        "std_rel_L2_u": float(np.std(rel_l2_u_list)) if rel_l2_u_list else 0.0,
        "std_rel_L2_v": float(np.std(rel_l2_v_list)) if rel_l2_v_list else 0.0,
        "mean_E": float(np.mean(E_mean_list)) if E_mean_list else 0.0,
        "mean_nu": float(np.mean(nu_mean_list)) if nu_mean_list else 0.0,
        "mean_force": float(np.mean(f_mean_list)) if f_mean_list else 0.0,
    }


def dump_bad_case_q4(samples, sid, epoch, it, args, reason="nonfinite"):
    os.makedirs(args.out_dir, exist_ok=True)
    s = samples[sid]
    gid = s.get("gid", sid)

    save_path = os.path.join(args.out_dir, f"bad_case_{reason}_epoch{epoch}_it{it}_sid{sid}_gid{gid}.npz")
    np.savez(
        save_path,
        gid=gid,
        xy=s["xy"],
        quad=s["quad"],
        uv_exact=s.get("uv_exact", None),
        top_edges=s.get("top_edges", None),
        bottom_nodes=s.get("bottom_nodes", None),
        E_node=s.get("E_node", None),
        nu_node=s.get("nu_node", None),
        node_forces=s.get("node_forces", None),
    )

    plot_mesh_with_materials_and_forces_q4(samples, args, sid=sid, tag=f"bad_{reason}_epoch{epoch}_it{it}")

    print("\n" + "="*80)
    print(f"[NaN/Inf DETECTED] reason={reason}")
    print(f"  epoch={epoch}, it={it}, sid(in split)={sid}, gid(in original npz)={gid}")
    print(f"  saved bad sample: {save_path}")
    print("="*80 + "\n")


@torch.no_grad()
def visualize_one_hyperelastic_Q4(samples, model, args, device, dtype, sid=0, tag="final"):
    model.eval()
    s = samples[sid]
    xy = torch.tensor(s["xy"], device=device, dtype=dtype)
    quad = torch.tensor(s["quad"], device=device, dtype=torch.long)
    top_edges = torch.tensor(s["top_edges"], device=device, dtype=torch.long)
    bottom_nodes = torch.tensor(s["bottom_nodes"], device=device, dtype=torch.long)
    uv_exact = torch.tensor(s["uv_exact"], device=device, dtype=dtype)
    E_node = torch.tensor(s["E_node"], device=device, dtype=dtype)
    nu_node = torch.tensor(s["nu_node"], device=device, dtype=dtype)
    node_forces = torch.tensor(s["node_forces"], device=device, dtype=dtype)

    Pi, U, W, uv_pred, Fg = total_potential_energy_Q4_hyperelastic_single(
        xy, quad, top_edges, bottom_nodes,
        model, E_node, nu_node, node_forces,
        use_soft_dirichlet=args.use_soft_dirichlet,
        Ly=args.Ly,
        mode=args.mode,
        dtype=dtype,
        fun_dim=args.fun_dim,
        material=args.material,
    )

    err = uv_pred - uv_exact
    l2_u = torch.sqrt(torch.mean(err[:, 0] ** 2)).item()
    l2_v = torch.sqrt(torch.mean(err[:, 1] ** 2)).item()
    ref_u = torch.sqrt(torch.mean(uv_exact[:, 0] ** 2)).item() + 1e-12
    ref_v = torch.sqrt(torch.mean(uv_exact[:, 1] ** 2)).item() + 1e-12
    rel_l2_u = l2_u / ref_u
    rel_l2_v = l2_v / ref_v
    linf = torch.max(torch.linalg.norm(err, dim=1)).item()

    fm = torch.sqrt(torch.sum(node_forces ** 2, dim=1))
    nz = fm[fm > 0]
    force_mean = nz.mean().item() if len(nz) > 0 else 0.0

    Jg = Fg[:, 0, 0] * Fg[:, 1, 1] - Fg[:, 0, 1] * Fg[:, 1, 0]
    J_mean, J_min, J_max = Jg.mean().item(), Jg.min().item(), Jg.max().item()

    print(f"[viz sid={sid} tag={tag}] Pi={Pi.item():.3e}  U={U.item():.3e}  W={W.item():.3e}")
    print(f"                L2(u)={rel_l2_u:.3e}  L2(v)={rel_l2_v:.3e}  Linf(|e|)={linf:.3e}")
    print(f"                E_mean={E_node.mean().item():.1f}  nu_mean={nu_node.mean().item():.3f}  Force_mean={force_mean:.3f}")
    print(f"                det(F)@GP: mean={J_mean:.3f}, min={J_min:.3f}, max={J_max:.3f}")

    x_np = s["xy"][:, 0]
    y_np = s["xy"][:, 1]
    uvp = uv_pred.detach().cpu().numpy()
    uve = uv_exact.detach().cpu().numpy()
    ep = uvp - uve

    u_pred, v_pred = uvp[:, 0], uvp[:, 1]
    u_exact, v_exact = uve[:, 0], uve[:, 1]
    u_err, v_err = ep[:, 0], ep[:, 1]

    umag_pred = np.sqrt(u_pred*u_pred + v_pred*v_pred)
    umag_exact = np.sqrt(u_exact*u_exact + v_exact*v_exact)
    umag_err = np.sqrt(u_err*u_err + v_err*v_err)

    def save_combined_scatter(pred, exact, err, name, err_label, cmap="coolwarm"):
        # This 3-panel figure is embedded at roughly a third of a printed
        # page's width in the paper (Figure 6, six of these in a 2x3
        # grid), so matplotlib's defaults are unreadable once downscaled
        # -- bumped explicitly, matching the sizing already used for
        # every other project figure.
        with plt.rc_context({
            'font.size': 20,
            'axes.titlesize': 24,
            'xtick.labelsize': 16,
            'ytick.labelsize': 16,
        }):
            fig, axes = plt.subplots(1, 3, figsize=(18, 5))
            vmin = min(pred.min(), exact.min())
            vmax = max(pred.max(), exact.max())

            sc1 = axes[0].scatter(x_np, y_np, c=pred, s=10, cmap=cmap, vmin=vmin, vmax=vmax)
            axes[0].set_aspect("equal"); axes[0].set_title("Prediction")
            cb1 = plt.colorbar(sc1, ax=axes[0]); cb1.ax.tick_params(labelsize=14)

            sc2 = axes[1].scatter(x_np, y_np, c=exact, s=10, cmap=cmap, vmin=vmin, vmax=vmax)
            axes[1].set_aspect("equal"); axes[1].set_title("Exact")
            cb2 = plt.colorbar(sc2, ax=axes[1]); cb2.ax.tick_params(labelsize=14)

            sc3 = axes[2].scatter(x_np, y_np, c=err, s=10, cmap=cmap)
            axes[2].set_aspect("equal"); axes[2].set_title(f"Error ({err_label})")
            cb3 = plt.colorbar(sc3, ax=axes[2]); cb3.ax.tick_params(labelsize=14)

            plt.tight_layout()
            plt.savefig(os.path.join(args.out_dir, f"{name}_combined_{tag}_sid{sid}.png"), dpi=300)
            plt.close()

    save_combined_scatter(u_pred, u_exact, u_err, "ux", f"L2={rel_l2_u:.3e}")
    save_combined_scatter(v_pred, v_exact, v_err, "uy", f"L2={rel_l2_v:.3e}")
    save_combined_scatter(umag_pred, umag_exact, umag_err, "umag", f"Linf={linf:.3e}")


# ============================================================
# 8) Train (Q4)
# ============================================================
def train_hyperelastic_Q4(args):
    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    dtype = torch.float32
    os.makedirs(args.out_dir, exist_ok=True)

    np.random.seed(args.seed)
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    Train_samples, Test_samples = load_fem_dataset_Q4_with_materials_and_random_force(
        args.path, args.ntrain, args.ntest
    )
    print(f"Loaded Q4 dataset: ntrain={len(Train_samples)}, ntest={len(Test_samples)}")

    for i in range(min(3, len(Train_samples))):
        s = Train_samples[i]
        fm = np.sqrt(np.sum(s["node_forces"]**2, axis=1))
        nz = fm[fm > 0]
        fmean = nz.mean() if len(nz) > 0 else 0.0
        print(f"Sample {i}: nodes={s['xy'].shape[0]}, quads={s['quad'].shape[0]}, "
              f"E_mean={s['E_node'].mean():.1f}, nu_mean={s['nu_node'].mean():.3f}, "
              f"Force_mean={fmean:.3f}, Force_nodes={len(nz)}")

    # Input normalization, installed BEFORE the model is built or resumed so
    # that every forward pass in this process -- training, validation, the
    # final evaluation -- sees the same transform. The statistics come from
    # the training split only; Test_samples are not touched.
    os.makedirs(args.out_dir, exist_ok=True)
    norm_path = os.path.join(args.out_dir, "input_norm.json")
    if int(getattr(args, "normalize_inputs", 0)):
        if os.path.exists(norm_path):
            # A resumed run MUST reuse the statistics the earlier epochs were
            # trained under. Recomputing them would be a silent train/train
            # mismatch across the resume boundary.
            with open(norm_path) as f:
                norm_stats = json.load(f)
            print(f"[input-norm] reusing {norm_path} from the earlier run")
            fresh = compute_input_norm(Train_samples, args.fun_dim)
            drift = max(abs(a - b) for a, b in zip(norm_stats["mean"], fresh["mean"]))
            assert drift < 1e-6 * max(1.0, max(abs(m) for m in fresh["mean"])), (
                f"input_norm.json disagrees with the current training set "
                f"(max mean drift {drift:g}) -- the data or --ntrain changed "
                f"under a resume; refusing to continue")
        else:
            norm_stats = compute_input_norm(Train_samples, args.fun_dim)
            with open(norm_path, "w") as f:
                json.dump(norm_stats, f, indent=1)
            print(f"[input-norm] computed from {len(Train_samples)} training "
                  f"samples and written to {norm_path}")
        set_input_norm(norm_stats)
        for c, m, s in zip(norm_stats["channels"], norm_stats["mean"], norm_stats["std"]):
            print(f"[input-norm]   {c:>3}: mean={m:12.5f}  std={s:12.5f}")
    else:
        set_input_norm(None)
        assert not os.path.exists(norm_path), (
            f"{norm_path} exists but --normalize_inputs is 0. This out_dir "
            f"holds a normalized run; training an unnormalized model into it "
            f"would produce a checkpoint that eval silently mis-scales. Use a "
            f"different --out_dir.")

    plot_mesh_with_materials_and_forces_q4(Train_samples, args, sid=0, tag="train_sample0")
    if len(Test_samples) > 0:
        plot_mesh_with_materials_and_forces_q4(Test_samples, args, sid=0, tag="test_sample0")

    model = get_model(args).Model(
        space_dim=2,
        n_layers=args.n_layers,
        n_hidden=args.n_hidden,
        dropout=args.dropout,
        n_head=args.n_heads,
        Time_Input=False,
        mlp_ratio=args.mlp_ratio,
        fun_dim=args.fun_dim,
        out_dim=2,
        slice_num=args.slice_num,
        ref=args.ref,
        unified_pos=args.unified_pos
    ).to(device)

    # Optimizer. The default is unchanged -- plain Adam, exactly what every
    # result in the report was produced with -- so nothing that already exists
    # moves. `--optimizer adamw_onecycle` exists only to fill the empty cell in
    # the point-7b comparison: the data-driven model was measured under both
    # recipes, the physics-informed one under only its own, and without this
    # the two cannot be ranked independently of the optimizer.
    if getattr(args, "optimizer", "adam") == "adamw_onecycle":
        opt = torch.optim.AdamW(model.parameters(), lr=args.lr,
                                weight_decay=args.weight_decay)
        _total = int(getattr(args, "onecycle_total_steps", 0)) or (
            args.epochs * max(1, len(Train_samples) // max(int(args.batch_size), 1)))
        onecycle = torch.optim.lr_scheduler.OneCycleLR(
            opt, max_lr=args.lr, total_steps=_total, pct_start=0.1)
        print(f"[optimizer] AdamW + OneCycleLR over {_total:,} steps "
              f"(max_lr={args.lr}, wd={args.weight_decay})")
    else:
        opt = torch.optim.Adam(model.parameters(), lr=args.lr,
                               weight_decay=args.weight_decay)
        onecycle = None

    ntrain = len(Train_samples)
    bs = max(int(args.batch_size), 1)
    validate_every = max(int(args.validate_every if getattr(args, "validate_every", None) else args.save_every), 1)
    metrics_history = []
    start_epoch = 1
    opt_steps = 0
    train_wall_clock = 0.0
    best_val_error = None
    best_epoch = None
    patience_counter = 0

    if os.path.exists(os.path.join(args.out_dir, "model_final.pt")):
        print(f"[resume] {args.out_dir}/model_final.pt already exists -- this case is already fully trained, skipping.")
        return
    if os.path.exists(os.path.join(args.out_dir, "EARLY_STOPPED")):
        print(f"[resume] {args.out_dir}/EARLY_STOPPED marker found -- this case already stopped early, skipping.")
        return

    ckpt_path, last_epoch = find_latest_checkpoint(args.out_dir)
    if ckpt_path is not None:
        print(f"[resume] Found checkpoint {ckpt_path} (epoch {last_epoch}) -- resuming from epoch {last_epoch + 1}")
        model.load_state_dict(torch.load(ckpt_path, map_location=device))
        start_epoch = last_epoch + 1

        metrics_history_path = os.path.join(args.out_dir, "metrics_history.json")
        if os.path.exists(metrics_history_path):
            with open(metrics_history_path) as f:
                metrics_history = json.load(f)
            for rec in metrics_history:
                train_wall_clock = max(train_wall_clock, rec.get("cumulative_wall_clock_s", 0.0))
                opt_steps = max(opt_steps, rec.get("opt_steps", 0))
                if "val_error" in rec and (best_val_error is None or rec["val_error"] < best_val_error - 1e-12):
                    best_val_error = rec["val_error"]
                    best_epoch = rec["epoch"]

        best_ckpt_meta_path = os.path.join(args.out_dir, "best_checkpoint_meta.json")
        if os.path.exists(best_ckpt_meta_path):
            with open(best_ckpt_meta_path) as f:
                best_meta = json.load(f)
            best_val_error = best_meta.get("best_val_error", best_val_error)
            best_epoch = best_meta.get("best_epoch", best_epoch)
            patience_counter = best_meta.get("patience_counter", 0)

        # Replay the LR-decay schedule so resuming doesn't jump back to the
        # full initial LR (see the epoch%1000==0 decay below)
        e = 1000
        while e < args.epochs and e < start_epoch:
            for pg in opt.param_groups:
                pg["lr"] *= 0.9
            e += 1000
        print(f"[resume] LR after replaying decay schedule: {opt.param_groups[0]['lr']:.2e}")

    early_stop_patience = int(getattr(args, "early_stop_patience", 0))
    early_stop_min_delta = float(getattr(args, "early_stop_min_delta", 1e-4))
    stopped_early = False

    # Total device memory (constant for the run) and a running peak of
    # (total - free) sampled via torch.cuda.mem_get_info(), i.e. the same
    # "how much of the whole GPU is in use" figure nvidia-smi would show --
    # this differs from max_memory_allocated/reserved below, which are
    # PyTorch's own allocator bookkeeping and do not include the CUDA
    # context's fixed overhead or any other process sharing the device.
    device_total_mb = (torch.cuda.mem_get_info(device)[1] / 1e6) if device.type == "cuda" else 0.0

    for epoch in range(start_epoch, args.epochs + 1):
        order = np.random.permutation(ntrain) if getattr(args, "shuffle", 1) else np.arange(ntrain)

        model.train()
        epoch_t0 = time.time()
        skipped = 0
        epoch_peak_device_used_mb = 0.0

        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)

        for bi, start in enumerate(range(0, ntrain, bs)):
            batch_idx = order[start:start + bs]
            batch_samples = [Train_samples[i] for i in batch_idx]

            xy = torch.tensor(batch_samples[0]["xy"], device=device, dtype=dtype)
            quad = torch.tensor(batch_samples[0]["quad"], device=device, dtype=torch.long)
            top_edges = torch.tensor(batch_samples[0]["top_edges"], device=device, dtype=torch.long)
            bottom_nodes = torch.tensor(batch_samples[0]["bottom_nodes"], device=device, dtype=torch.long)
            E_batch = torch.tensor(np.stack([s["E_node"] for s in batch_samples]), device=device, dtype=dtype)
            nu_batch = torch.tensor(np.stack([s["nu_node"] for s in batch_samples]), device=device, dtype=dtype)
            force_batch = torch.tensor(np.stack([s["node_forces"] for s in batch_samples]), device=device, dtype=dtype)

            Pi, U, W, uv_pred, Fg = total_potential_energy_Q4_hyperelastic(
                xy, quad, top_edges, bottom_nodes,
                model, E_batch, nu_batch, force_batch,
                use_soft_dirichlet=args.use_soft_dirichlet,
                Ly=args.Ly,
                mode=args.mode,
                dtype=dtype,
                fun_dim=args.fun_dim,
                material=args.material,
            )

            finite_mask = torch.isfinite(Pi) & torch.isfinite(uv_pred).all(dim=(1, 2))
            if not finite_mask.all():
                bad_local = torch.nonzero(~finite_mask).flatten().tolist()
                skipped += len(bad_local)
                for li in bad_local:
                    dump_bad_case_q4(Train_samples, int(batch_idx[li]), epoch, start, args, reason="nonfinite")
                if not finite_mask.any():
                    opt.zero_grad(set_to_none=True)
                    continue
                loss = Pi[finite_mask].mean()
            else:
                loss = Pi.mean()

            opt.zero_grad(set_to_none=True)
            loss.backward()

            bad_grad = any(p.grad is not None and not torch.isfinite(p.grad).all() for p in model.parameters())
            if bad_grad:
                skipped += len(batch_idx)
                opt.zero_grad(set_to_none=True)
                continue

            if args.grad_clip is not None and args.grad_clip > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)

            opt.step()
            if onecycle is not None and onecycle.last_epoch + 1 < onecycle.total_steps:
                onecycle.step()
            opt_steps += 1

            if device.type == "cuda":
                free_b, total_b = torch.cuda.mem_get_info(device)
                epoch_peak_device_used_mb = max(epoch_peak_device_used_mb, (total_b - free_b) / 1e6)

            if bi % args.print_every == 0:
                fm = torch.sqrt(torch.sum(force_batch ** 2, dim=2))
                nz = fm[fm > 0]
                fmean = nz.mean().item() if nz.numel() > 0 else 0.0
                Jg = Fg[:, 0, 0] * Fg[:, 1, 1] - Fg[:, 0, 1] * Fg[:, 1, 0]
                Jmean = Jg.mean().item()
                print(f"[batch {bi:5d}] (epoch={epoch}) Pi_mean={loss.item():.6e}  "
                      f"E={E_batch.mean().item():.1f}  nu={nu_batch.mean().item():.3f}  "
                      f"Force={fmean:.3f}  detF@GP={Jmean:.3f}  opt_steps={opt_steps}")

        epoch_time = time.time() - epoch_t0
        train_wall_clock += epoch_time

        if skipped > 0:
            print(f"[epoch {epoch}] skipped={skipped} bad samples")

        do_checkpoint = (epoch % args.save_every == 0)
        do_validate = (epoch % validate_every == 0)

        if do_checkpoint:
            torch.save(model.state_dict(), os.path.join(args.out_dir, f"model_epoch{epoch}.pt"))

        if do_validate:
            viz_sid = random.randint(0, ntrain - 1)
            visualize_one_hyperelastic_Q4(
                Train_samples, model, args, device, dtype,
                sid=viz_sid, tag=f"epoch{epoch}"
            )

            gpu_mem_mb = (torch.cuda.max_memory_allocated(device) / 1e6) if device.type == "cuda" else 0.0
            gpu_mem_reserved_mb = (torch.cuda.max_memory_reserved(device) / 1e6) if device.type == "cuda" else 0.0
            gpu_mem_device_mb = epoch_peak_device_used_mb

            metrics = evaluate_dataset_hyperelastic_Q4(Test_samples, model, args, device, dtype)
            val_error = 0.5 * (metrics["mean_rel_L2_u"] + metrics["mean_rel_L2_v"])
            print("===== Test-set Evaluation =====")
            print(f"Mean Rel L2(u): {metrics['mean_rel_L2_u']:.3e}")
            print(f"Mean Rel L2(v): {metrics['mean_rel_L2_v']:.3e}")
            print(f"Std  Rel L2(u): {metrics['std_rel_L2_u']:.3e}")
            print(f"Std  Rel L2(v): {metrics['std_rel_L2_v']:.3e}")
            print(f"Avg E: {metrics['mean_E']:.1f}")
            print(f"Avg nu: {metrics['mean_nu']:.3f}")
            print(f"Avg Force: {metrics['mean_force']:.3f}")
            print(f"Val error (mean of Rel L2 u,v): {val_error:.3e}  "
                  f"epoch_time={epoch_time:.2f}s  cum_wall_clock={train_wall_clock:.1f}s  "
                  f"gpu_peak_mem_allocated={gpu_mem_mb:.1f}MB  gpu_peak_mem_reserved={gpu_mem_reserved_mb:.1f}MB  "
                  f"gpu_peak_mem_device={gpu_mem_device_mb:.1f}MB/{device_total_mb:.1f}MB  "
                  f"opt_steps={opt_steps}")

            is_best = (best_val_error is None) or (val_error < best_val_error - early_stop_min_delta)
            if is_best:
                best_val_error = val_error
                best_epoch = epoch
                patience_counter = 0
                torch.save(model.state_dict(), os.path.join(args.out_dir, "model_best.pt"))
                with open(os.path.join(args.out_dir, "best_checkpoint_meta.json"), "w") as f:
                    json.dump({"best_val_error": best_val_error, "best_epoch": best_epoch,
                               "patience_counter": patience_counter}, f, indent=2)
                print(f"[best] New best val_error={best_val_error:.3e} at epoch={best_epoch} -> model_best.pt")
            else:
                patience_counter += 1
                with open(os.path.join(args.out_dir, "best_checkpoint_meta.json"), "w") as f:
                    json.dump({"best_val_error": best_val_error, "best_epoch": best_epoch,
                               "patience_counter": patience_counter}, f, indent=2)

            metrics_record = {
                "epoch": int(epoch), **metrics,
                "val_error": val_error,
                "is_best": bool(is_best),
                "epoch_time_s": epoch_time,
                "cumulative_wall_clock_s": train_wall_clock,
                "gpu_peak_mem_mb": gpu_mem_mb,
                "gpu_peak_mem_reserved_mb": gpu_mem_reserved_mb,
                "gpu_peak_mem_device_mb": gpu_mem_device_mb,
                "gpu_device_total_mb": device_total_mb,
                "opt_steps": opt_steps,
                "batch_size": bs,
            }
            metrics_history.append(metrics_record)
            with open(os.path.join(args.out_dir, "metrics_history.json"), "w") as f:
                json.dump(metrics_history, f, indent=2)

            if early_stop_patience > 0 and patience_counter >= early_stop_patience:
                print(f"[early stop] val_error hasn't improved for {patience_counter} validation "
                      f"events (patience={early_stop_patience}) -- stopping at epoch {epoch}, "
                      f"best was epoch {best_epoch} (val_error={best_val_error:.3e})")
                stopped_early = True
                break

        if epoch % 1000 == 0 and epoch < args.epochs:
            for pg in opt.param_groups:
                pg["lr"] *= 0.9
            print(f"[epoch {epoch}] lr -> {opt.param_groups[0]['lr']:.2e}")

    if not stopped_early:
        torch.save(model.state_dict(), os.path.join(args.out_dir, "model_final.pt"))
    else:
        # Early-stopped runs keep model_best.pt as the deliverable and are
        # marked complete via a marker file (not model_final.pt) so a
        # re-run of this case is correctly treated as already finished
        # without pretending training reached args.epochs.
        with open(os.path.join(args.out_dir, "EARLY_STOPPED"), "w") as f:
            f.write(f"stopped_at_epoch={epoch}\nbest_epoch={best_epoch}\nbest_val_error={best_val_error}\n")

    final_metrics = evaluate_dataset_hyperelastic_Q4(Test_samples, model, args, device, dtype)
    print("\n" + "="*80)
    print("FINAL RESULTS:")
    print(f"Mean Rel L2(u): {final_metrics['mean_rel_L2_u']:.3e}")
    print(f"Mean Rel L2(v): {final_metrics['mean_rel_L2_v']:.3e}")
    print(f"Avg E: {final_metrics['mean_E']:.1f}")
    print(f"Avg nu: {final_metrics['mean_nu']:.3f}")
    print(f"Avg Force: {final_metrics['mean_force']:.3f}")
    if best_epoch is not None:
        print(f"Best val_error: {best_val_error:.3e} at epoch {best_epoch} (see model_best.pt)")
    print(f"Total wall clock: {train_wall_clock:.1f}s over {opt_steps} optimizer steps (batch_size={bs})")
    print("="*80)

    inference_stats = benchmark_inference_latency_Q4(Test_samples, model, args, device, dtype)
    print(f"Inference latency (batch_size=1, forward pass only, no training): "
          f"{inference_stats['inference_ms_per_sample']:.4f} ms/sample "
          f"(averaged over {inference_stats['inference_n_repeats']} calls, {device.type})")
    with open(os.path.join(args.out_dir, "inference_latency.json"), "w") as f:
        json.dump(inference_stats, f, indent=2)

    print("\nTraining completed!")
    print(f"Results saved to: {args.out_dir}")


# ============================================================
# 9) Main
# ============================================================
def main():
    parser = argparse.ArgumentParser(
        "PFEM/Transolver on FEM Q4 meshes -- B1 (unit square, top-edge traction, fixed bottom)"
    )

    parser.add_argument("--path", type=str, default="./omar_pfem/data/training_data_B1_q4/hyperelastic_training_data_q4.npz")
    parser.add_argument("--Lx", type=float, default=1.0)
    parser.add_argument("--Ly", type=float, default=1.0)

    parser.add_argument("--material", type=str, default="neo_hookean",
                         choices=["neo_hookean", "mooney_rivlin", "arruda_boyce"])

    parser.add_argument("--mode", type=str, default="plane_strain", choices=["plane_stress", "plane_strain"])

    parser.add_argument("--lr", type=float, default=2e-3)
    parser.add_argument("--epochs", type=int, default=10000)
    parser.add_argument("--grad_clip", type=float, default=1.0)
    parser.add_argument("--print_every", type=int, default=10)
    parser.add_argument("--save_every", type=int, default=10,
                         help="Epoch cadence for full model_epoch{N}.pt checkpoints (resume points)")
    parser.add_argument("--validate_every", type=int, default=None,
                         help="Epoch cadence for test-set evaluation + best-checkpoint tracking; "
                              "defaults to --save_every if not set. Decoupled from --save_every "
                              "so validation can run more often (e.g. every 25-50 epochs) without "
                              "writing a full checkpoint file every time.")
    parser.add_argument("--early_stop_patience", type=int, default=0,
                         help="Stop if val_error hasn't improved for this many validation events "
                              "(0 disables early stopping)")
    parser.add_argument("--early_stop_min_delta", type=float, default=1e-4,
                         help="Minimum val_error improvement to reset the early-stopping patience counter")
    parser.add_argument("--seed", type=int, default=2025)
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--out_dir", type=str, default="./results_B1_transolver")
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--optimizer", type=str, default="adam",
                        choices=["adam", "adamw_onecycle"],
                        help="adam is the default every reported result used. "
                             "adamw_onecycle fills the point-7b 2x2's empty cell.")
    parser.add_argument("--onecycle_total_steps", type=int, default=0,
                        help="total steps for OneCycleLR; 0 derives it from "
                             "epochs x steps-per-epoch")
    parser.add_argument("--batch_size", type=int, default=1,
                         help="Real mini-batch size (parallel forward pass over this many samples "
                              "at once, all sharing B1's fixed mesh) -- not gradient accumulation.")
    parser.add_argument("--shuffle", type=int, default=0)

    parser.add_argument("--ntrain", type=int, default=35)
    parser.add_argument("--ntest", type=int, default=10)

    parser.add_argument("--use_soft_dirichlet", type=int, default=1)

    parser.add_argument("--model", type=str, default="Transolver_Irregular_Mesh")
    parser.add_argument("--n_hidden", type=int, default=256)
    parser.add_argument("--n_layers", type=int, default=4)
    parser.add_argument("--n_heads", type=int, default=8)
    parser.add_argument("--mlp_ratio", type=int, default=2)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--unified_pos", type=int, default=0)
    parser.add_argument("--ref", type=int, default=16)
    parser.add_argument("--slice_num", type=int, default=128)

    parser.add_argument("--fun_dim", type=int, default=4)
    parser.add_argument("--normalize_inputs", type=int, default=0,
                        help="Standardize the network's input channels (E, nu, "
                             "forces) by the TRAINING SET's own per-channel mean "
                             "and std, saved to input_norm.json in --out_dir and "
                             "reused verbatim at evaluation. Default 0 = raw "
                             "channels, which is what every result in the report "
                             "to date was produced with. This is the mitigation "
                             "the advisor asked to be tested in round 6, point 1.")

    args = parser.parse_args()
    args.use_soft_dirichlet = bool(args.use_soft_dirichlet)

    if not os.path.exists(args.path):
        raise FileNotFoundError(f"Dataset file not found: {args.path}")

    print(f"Using dataset: {args.path}")
    print(f"Output dir: {args.out_dir}")
    print(f"Material: {args.material}")
    print(f"fun_dim={args.fun_dim}  (3->[E,nu,fy], 4->[E,nu,fx,fy])")

    train_hyperelastic_Q4(args)


if __name__ == "__main__":
    main()
