"""
Mesh (h-refinement) convergence study using the matrix-free Newton-CG
solver, computing L2 norm, H1 semi-norm, and energy-norm errors (plus
observed convergence rates) against a common fine-mesh reference solution
-- and comparing Q4 (bilinear) against Q9 (biquadratic) at the same
corner-node resolutions -- per the advisor's fourth-round request.

Norm definitions (all against the SAME fixed analytic (E, nu, load) field,
reusing mesh_convergence.py's own AnalyticFieldB1/B2 for the same reason it
uses them: a genuine closed-form function of (x, y) is required so the
identical physical problem is solved at every mesh size):

  - L2 norm:  ||e||_L2 = sqrt( integral_Omega |e|^2 dOmega ), e = u_h -
    u_ref, evaluated via Gauss quadrature on the COARSE mesh's own
    elements; u_ref (known only at the fine reference mesh's own nodes) is
    evaluated at each coarse Gauss point EXACTLY, via direct point location
    into the fine mesh's own element (index arithmetic on its known
    structured grid, no search) followed by that element's own shape
    functions (see evaluate_fe_field_and_gradient) -- not a generic
    re-triangulation/interpolation of its nodes.
  - H1 semi-norm: ||e||_H1 = sqrt( integral_Omega |grad(e)|^2 dOmega ).
    grad(u_h) at each coarse Gauss point comes directly from the coarse
    element's own shape-function gradients (exact for that element).
    grad(u_ref) at the same points comes from the SAME point-located fine
    element's own shape-function gradients (exact for a piecewise-
    bilinear/biquadratic FE field) -- an earlier version of this module
    instead finite-differenced a generic Delaunay-triangulation
    interpolant of the fine mesh's nodes, which produced a gradient with a
    fixed noise floor that did NOT shrink as the coarse mesh was refined
    (a piecewise-linear interpolant's true gradient is only piecewise-
    constant; finite-differencing across its triangle boundaries measures
    interpolation artifacts, not the fine solution's own discretization
    error) -- this showed up empirically as a near-zero or even negative
    observed H1 convergence rate despite L2 and the energy norm both
    converging correctly, which is what prompted this fix.
  - Energy norm: relative error in total strain energy,
    |U(u_h) - U(u_ref)| / |U(u_ref)|, both computed via the same Gauss-
    quadrature energy assembly (matrix_free_solver.element_energy_order_agnostic)
    -- a global scalar that can look converged even where a pointwise
    L2/H1 error has not, and vice versa.
  - Peak PK1 stress QoI (added 2026-09-06, see compute_peak_stress_error):
    max Frobenius-norm first Piola-Kirchhoff stress over the coarse mesh's
    own Gauss points, compared between u_h and u_ref -- the specific
    engineering QoI the advisor's email named as an example ("maximum
    stresses or similar") when asking to check tolerance-vs-cost, which
    none of the three field norms above directly answers. Both fields use
    the SAME true material parameters sampled at that exact physical
    point, so the comparison isolates displacement-gradient error, not a
    material-sampling artifact. Also reports a quadrature-weighted L2 norm
    of the full stress-field error, alongside the single peak value.

Convergence rate: for two consecutive resolutions with errors e1 (coarser,
mesh size h1) and e2 (finer, h2), p = log(e1/e2) / log(h1/h2), plus a
single log-log least-squares fit across every resolution for a more robust
overall estimate. h is taken proportional to 1/(N-1) (N = corner nodes per
side), i.e. h1/h2 = (N2-1)/(N1-1).

Usage:
  python -m omar_pfem.high_dof_convergence_study \
      --geometry B1 --material neo_hookean \
      --resolutions 6,11,16,21,31,41 --fine_N 81 --orders Q4,Q9 \
      --out_json high_dof_convergence_B1_neo_hookean.json
"""
import argparse
import json
import os
import time

import numpy as np
import torch

from torch.func import grad as torch_grad

from omar_pfem.mesh_convergence import AnalyticFieldB1, AnalyticFieldB2
from omar_pfem.matrix_free_solver import (
    solve_matrix_free, element_energy_order_agnostic, precompute_shape_data, _gauss_2x2,
    _make_energy_fn, matrix_free_hvp,
)
from omar_pfem.data.q9_element import generate_grid_Q9, gauss_3x3, shape_Q9, _NODE_XI_ETA, _lagrange1d
from omar_pfem.data.fem_core import shape_Q4
from omar_pfem.materials_torch import get_material_fns as get_material_fns_torch


def shape_Q4_batched(xi, eta):
    """Vectorized shape_Q4: xi, eta are (Q,) arrays. Returns N (Q,4),
    dN_dxi (Q,4,2) -- avoids a Python-level loop over Gauss/query points,
    which otherwise dominates wall-clock time once thousands of points are
    evaluated (every coarse-mesh Gauss point, times several Newton
    corrections each, for the reference-field evaluation)."""
    N = 0.25 * np.stack([(1 - xi) * (1 - eta), (1 + xi) * (1 - eta),
                          (1 + xi) * (1 + eta), (1 - xi) * (1 + eta)], axis=-1)
    z = np.zeros_like(xi)
    dN_dxi = 0.25 * np.stack([
        np.stack([-(1 - eta), -(1 - xi)], axis=-1),
        np.stack([(1 - eta), -(1 + xi)], axis=-1),
        np.stack([(1 + eta), (1 + xi)], axis=-1),
        np.stack([-(1 + eta), (1 - xi)], axis=-1),
    ], axis=1)
    return N, dN_dxi


def shape_Q9_batched(xi, eta):
    """Vectorized shape_Q9 (see shape_Q4_batched's rationale). xi, eta:
    (Q,) arrays. Returns N (Q,9), dN_dxi (Q,9,2)."""
    Q = xi.shape[0]
    N = np.zeros((Q, 9))
    dN_dxi = np.zeros((Q, 9, 2))
    for k, (nx, ny) in enumerate(_NODE_XI_ETA):
        Lx, dLx = _lagrange1d(xi, nx)
        Ly, dLy = _lagrange1d(eta, ny)
        N[:, k] = Lx * Ly
        dN_dxi[:, k, 0] = dLx * Ly
        dN_dxi[:, k, 1] = Lx * dLy
    return N, dN_dxi


def _edge_quadrature(order):
    """1D Gauss points/weights along a reference edge: 2-point for Q4
    (matches data_generate_B1/B2.py's own edge quadrature exactly), 3-point
    for Q9 -- consistent with its 3x3 interior rule, and needed because a
    Q9 edge's own shape functions are themselves quadratic in the edge
    coordinate, not linear."""
    if order == "Q4":
        g = 1.0 / np.sqrt(3.0)
        return [(-g, 1.0), (g, 1.0)]
    g = np.sqrt(3.0 / 5.0)
    return [(-g, 5.0 / 9.0), (0.0, 8.0 / 9.0), (g, 5.0 / 9.0)]


def _shape_fn(order):
    return shape_Q4 if order == "Q4" else shape_Q9


def assemble_traction_top_generic(nodes, elements, Ly, ty_interp, order, tol=1e-9):
    """Order-agnostic replacement for data_generate_B1.assemble_traction_top_spatial:
    identical physics and quadrature convention for Q4 (verified to reduce
    to exactly the same local-node pair), generalized to also correctly
    load a Q9 element's own edge midside node -- the ORIGINAL Q4-only
    function silently ignores that node entirely if reused on a Q9 mesh,
    which is a real (not just cosmetic) bug: it would under-integrate the
    top-edge traction on every Q9 mesh."""
    n_nodes = nodes.shape[0]
    Fext = np.zeros(2 * n_nodes, dtype=float)
    shape_fn = _shape_fn(order)
    gps = _edge_quadrature(order)
    # Corner indices spanning the top edge (eta=+1), used only to check
    # whether THIS element is a boundary element and to get its edge
    # length -- same corner pair as Q4 for both orders, since Q9's corner
    # ordering matches Q4's by construction (see q9_element.py).
    for e in elements:
        Xe = nodes[e]
        y_top_a, y_top_b = Xe[2, 1], Xe[3, 1]
        if abs(y_top_a - Ly) < tol and abs(y_top_b - Ly) < tol:
            edge_len = np.linalg.norm(Xe[3] - Xe[2])
            for (xi, w1d) in gps:
                N, _ = shape_fn(xi, 1.0)
                x_pos = float(N @ Xe[:, 0])
                ty_value = ty_interp(np.array([[x_pos, Ly]]))[0]
                t = np.array([0.0, ty_value], dtype=float)
                Jedge = edge_len / 2.0
                for a in range(len(N)):
                    Fext[2 * e[a]:2 * e[a] + 2] += N[a] * t * (w1d * Jedge)
    return Fext


def assemble_traction_inner_generic(nodes, elements, R_in, p_interp, order, tol=1e-9):
    """Order-agnostic replacement for data_generate_B2.assemble_traction_inner_curved,
    same rationale as assemble_traction_top_generic above."""
    n_nodes = nodes.shape[0]
    Fext = np.zeros(2 * n_nodes, dtype=float)
    shape_fn = _shape_fn(order)
    gps = _edge_quadrature(order)
    for e in elements:
        Xe = nodes[e]
        r1 = np.linalg.norm(Xe[0])
        r4 = np.linalg.norm(Xe[3])
        if abs(r1 - R_in) < tol and abs(r4 - R_in) < tol:
            X1, X4 = Xe[0], Xe[3]
            edge_vec = X4 - X1
            edge_len = np.linalg.norm(edge_vec)
            tangent_hat = edge_vec / edge_len
            normal = np.array([tangent_hat[1], -tangent_hat[0]])
            midpoint = 0.5 * (X1 + X4)
            if np.dot(normal, midpoint) < 0:
                normal = -normal
            for (eta, w1d) in gps:
                N, _ = shape_fn(-1.0, eta)
                pos = N @ Xe
                theta_pos = np.arctan2(pos[1], pos[0])
                p_value = p_interp(np.array([[theta_pos, R_in]]))[0]
                t = p_value * normal
                Jedge = edge_len / 2.0
                for a in range(len(N)):
                    Fext[2 * e[a]:2 * e[a] + 2] += N[a] * t * (w1d * Jedge)
    return Fext


def build_mesh_and_bcs(geometry, order, N, material, device, dtype, field_fns=None):
    """field_fns: optional {"E":..., "nu":..., "ty" or "p":...} override,
    defaulting to None (the original AnalyticFieldB1/B2 behaviour, used by
    every existing caller -- the Table-6a-style FEM-vs-FEM mesh-convergence
    studies this module's own docstring says are "against the SAME fixed
    analytic (E, nu, load) field"). Added 2026-09-18 so round-12 point 1's
    energy-norm QoI can instead be computed against the SAME
    ParametricFieldB1/B2(seed) realization the operator itself was
    evaluated on -- see run_qoi_study_consistent_field_b1/b2 in
    no_accuracy_at_n1401.py for why this distinction matters (FEM's own
    accuracy and the operator's own accuracy were previously being measured
    on two DIFFERENT physical problems, not just two different mesh
    resolutions of the same one)."""
    if geometry == "B1":
        Lx = Ly = 1.0
        if field_fns is not None:
            E_fn, nu_fn, ty_fn = field_fns["E"], field_fns["nu"], field_fns["ty"]
        else:
            E_fn, nu_fn, ty_fn = AnalyticFieldB1("E"), AnalyticFieldB1("nu"), AnalyticFieldB1("ty")
        if order == "Q4":
            from omar_pfem.data.data_generate_B1 import generate_grid_Q4
            nodes, elements = generate_grid_Q4(Lx, Ly, N, N)
        else:
            nodes, elements = generate_grid_Q9(Lx, Ly, N, N)
        tolx = 1e-9
        bottom_nodes = np.where(np.abs(nodes[:, 1]) < tolx)[0]
        fixed_dofs = np.concatenate([2 * bottom_nodes, 2 * bottom_nodes + 1])
        fext_full = assemble_traction_top_generic(nodes, elements, Ly, ty_fn, order)
        from omar_pfem.gpu_fem_solver import precompute_element_params_B1 as precompute_params
        elem_params = precompute_params(nodes, elements, E_fn, nu_fn, material)
    else:
        R_in, R_out = 1.0, 2.0
        if field_fns is not None:
            E_fn, nu_fn, p_fn = field_fns["E"], field_fns["nu"], field_fns["p"]
        else:
            E_fn, nu_fn, p_fn = AnalyticFieldB2("E"), AnalyticFieldB2("nu"), AnalyticFieldB2("p")
        if order == "Q4":
            from omar_pfem.data.data_generate_B2 import generate_grid_Q4_ring
            nodes, elements = generate_grid_Q4_ring(R_in, R_out, N, N)
        else:
            # Polar-mapped Q9 mesh: build the Q9 reference grid in (r, theta)
            # -- r FAST, theta SLOW, matching generate_grid_Q4_ring's own
            # convention exactly (see that function's docstring) so both
            # orders share one element-traversal convention for the same
            # geometry -- then map to Cartesian.
            theta_max = np.pi / 2
            nodes_polar, elements = generate_grid_Q9(R_out - R_in, theta_max, N, N)
            r = nodes_polar[:, 0] + R_in
            theta = nodes_polar[:, 1]
            nodes = np.stack([r * np.cos(theta), r * np.sin(theta)], axis=1)
        tolx = 1e-9
        theta0_nodes = np.where(np.abs(nodes[:, 1]) < tolx)[0]
        thetahalfpi_nodes = np.where(np.abs(nodes[:, 0]) < tolx)[0]
        fixed_dofs = np.concatenate([2 * theta0_nodes + 1, 2 * thetahalfpi_nodes])
        fext_full = assemble_traction_inner_generic(nodes, elements, R_in, p_fn, order)
        from omar_pfem.gpu_fem_solver import precompute_element_params_B2 as precompute_params
        elem_params = precompute_params(nodes, elements, E_fn, nu_fn, material)

    ndof = 2 * len(nodes)
    free_dofs = np.setdiff1d(np.arange(ndof), fixed_dofs)
    return nodes, elements, free_dofs, fext_full, elem_params


def solve_one(geometry, order, N, material, device, dtype, cg_tol, newton_tol,
              use_jacobi=True, precond_kind="jacobi", cg_max_iter=2000, verbose=False,
              checkpoint_path=None, cg_progress_every=None, cg_checkpoint_every=2000,
              mg_min_coarse_n=13, mg_max_levels=8, hvp_method="autodiff"):
    nodes, elements, free_dofs, fext_full, elem_params_np = build_mesh_and_bcs(
        geometry, order, N, material, device, dtype)

    xy_t = torch.tensor(nodes, dtype=dtype, device=device)
    quad_t = torch.tensor(elements, dtype=torch.long, device=device)
    free_dofs_t = torch.tensor(free_dofs, dtype=torch.long, device=device)
    elem_params_t = tuple(torch.tensor(p, dtype=dtype, device=device) for p in elem_params_np)
    fext_free_t = torch.tensor(fext_full[free_dofs], dtype=dtype, device=device)

    mg_hierarchy = None
    if precond_kind == "mgv":
        # Builds the SAME kind of coarser meshes solve_matrix_free's own
        # Jacobi/block2x2 branches never need, by calling this file's own
        # build_mesh_and_bcs at successively coarser N (same geometry,
        # material, and BC convention -- not a separate mesh-generation
        # path), matching validate_multigrid_precond.py's own hierarchy
        # construction exactly, since that is what was actually validated
        # (correctness + iteration-count) before this was ever pointed at
        # a real N=401/701 problem.
        from omar_pfem.multigrid_precond import build_mg_hierarchy, coarsen_N
        Ns_mg = [N]
        while True:
            nc = coarsen_N(Ns_mg[-1])
            if nc is None or nc < mg_min_coarse_n or len(Ns_mg) >= mg_max_levels:
                break
            Ns_mg.append(nc)
        mesh_tuples = [(N, nodes, elements, free_dofs, elem_params_np)]
        for n in Ns_mg[1:]:
            c_nodes, c_elements, c_free, _c_fext, c_params = build_mesh_and_bcs(
                geometry, order, n, material, device, dtype)
            mesh_tuples.append((n, c_nodes, c_elements, c_free, c_params))
        mg_hierarchy = build_mg_hierarchy(mesh_tuples, dtype, device)
        print(f"  [mgv] hierarchy N: {Ns_mg} ({len(mesh_tuples)} levels)")

    t0 = time.time()
    u_free, stats = solve_matrix_free(
        xy_t, quad_t, free_dofs_t, elem_params_t, fext_free_t, n_free=len(free_dofs),
        material=material, order=order, nsteps=10, newton_max=30,
        newton_tol=newton_tol, cg_tol=cg_tol, cg_max_iter=cg_max_iter, use_jacobi=use_jacobi,
        precond_kind=precond_kind, mg_hierarchy=mg_hierarchy,
        device=device, dtype=dtype, verbose=verbose, checkpoint_path=checkpoint_path,
        cg_progress_every=cg_progress_every, cg_checkpoint_every=cg_checkpoint_every,
        hvp_method=hvp_method)
    wall_s = time.time() - t0

    ndof = 2 * len(nodes)
    u_full = torch.zeros(ndof, dtype=dtype, device=device)
    u_full = u_full.index_copy(0, free_dofs_t, u_free)

    shape_data = precompute_shape_data(order, device, dtype)
    energy_density_fn, _ = get_material_fns_torch(material)
    U = element_energy_order_agnostic(xy_t, quad_t, u_full.reshape(len(nodes), 2),
                                       elem_params_t, energy_density_fn, shape_data, dtype)

    return {
        "nodes": nodes, "elements": elements, "u": u_full.reshape(len(nodes), 2).cpu().numpy(),
        "N": N, "n_dof": ndof, "n_free_dof": len(free_dofs), "strain_energy": float(U.item()),
        "wall_clock_s": wall_s, "stats": stats,
    }


def gauss_points_and_weights_physical(nodes, elements, order):
    """Physical (x,y) coordinates, detJ, and weight of every Gauss point of
    every element in a mesh -- used both to integrate the L2/H1 errors and
    to evaluate u_h / grad(u_h) there via the coarse mesh's OWN shape
    functions (exact, since these are that mesh's own quadrature points).
    Vectorized over elements (each of the few Gauss points is the same
    reference location for every element, so N/dN_dxi there are computed
    ONCE and broadcast, not recomputed per element)."""
    gauss = _gauss_2x2() if order == "Q4" else gauss_3x3()
    shape_fn_batched = shape_Q4_batched if order == "Q4" else shape_Q9_batched
    n_elements = len(elements)
    Xe_all = nodes[elements]  # (n_elements, n_local, 2)

    pts, detJs, ws, Ns, dN_dXs, elem_idx = [], [], [], [], [], []
    for (xi, eta, w) in gauss:
        xi_arr = np.full(n_elements, xi)
        eta_arr = np.full(n_elements, eta)
        N, dN_dxi = shape_fn_batched(xi_arr, eta_arr)              # (n_elements, n_local), (n_elements, n_local, 2)
        J0 = np.einsum("qai,qaj->qij", Xe_all, dN_dxi)             # (n_elements, 2, 2)
        detJ0 = J0[:, 0, 0] * J0[:, 1, 1] - J0[:, 0, 1] * J0[:, 1, 0]
        invJ0 = np.zeros_like(J0)
        invJ0[:, 0, 0] = J0[:, 1, 1] / detJ0
        invJ0[:, 1, 1] = J0[:, 0, 0] / detJ0
        invJ0[:, 0, 1] = -J0[:, 0, 1] / detJ0
        invJ0[:, 1, 0] = -J0[:, 1, 0] / detJ0
        dN_dX = np.einsum("qaj,qjk->qak", dN_dxi, invJ0)           # (n_elements, n_local, 2)
        phys = np.einsum("qa,qad->qd", N, Xe_all)                  # (n_elements, 2)

        pts.append(phys); detJs.append(detJ0); ws.append(np.full(n_elements, w))
        Ns.append(N); dN_dXs.append(dN_dX); elem_idx.append(np.arange(n_elements))

    return (np.concatenate(pts), np.concatenate(detJs), np.concatenate(ws),
            np.concatenate(Ns), np.concatenate(dN_dXs), np.concatenate(elem_idx))


def _physical_to_normalized(pts, geometry, R_in=1.0, R_out=2.0, theta_max=np.pi / 2, Lx=1.0, Ly=1.0):
    """Maps physical (x, y) points to the mesh generators' own [0,1]x[0,1]
    structured reference coordinates: direct for B1 (Cartesian), via
    (r, theta) for B2 -- r is the FAST index (x_norm), theta the SLOW index
    (y_norm), matching generate_grid_Q4_ring's own convention (and, after
    the fix above, generate_grid_Q9's B2 call)."""
    if geometry == "B1":
        return pts[:, 0] / Lx, pts[:, 1] / Ly
    r = np.linalg.norm(pts, axis=1)
    theta = np.arctan2(pts[:, 1], pts[:, 0])
    return (r - R_in) / (R_out - R_in), theta / theta_max


def evaluate_fe_field_and_gradient(query_pts, fine, order, geometry, **geom_kwargs):
    """Exact FE evaluation of a fine structured mesh's own displacement
    field AND its gradient at arbitrary physical query points, via direct
    point location (index arithmetic on the known structured grid, no
    search) into the fine mesh's own element, followed by that element's
    own shape functions/gradients -- replacing an earlier version that
    finite-differenced a generic Delaunay-triangulation interpolant, which
    produced a gradient with a fixed noise floor that did not shrink as
    the COARSE mesh was refined (a piecewise-linear interpolant's true
    gradient is only piecewise-CONSTANT; finite-differencing across its
    triangle boundaries injects error that is NOT the fine solution's own
    discretization error). This version is both more correct (uses the
    fine mesh's own, already-known shape functions exactly, not a
    re-triangulation of its nodes) and faster (index arithmetic, not a
    Delaunay build + per-point interpolator calls)."""
    nodes_f, elements_f, u_f, N_fine = fine["nodes"], fine["elements"], fine["u"], fine["N"]
    nx_elem = N_fine - 1
    ny_elem = N_fine - 1

    x_norm, y_norm = _physical_to_normalized(query_pts, geometry, **geom_kwargs)
    x_norm = np.clip(x_norm, 0.0, 1.0)
    y_norm = np.clip(y_norm, 0.0, 1.0)

    ie = np.clip(np.floor(x_norm * nx_elem).astype(int), 0, nx_elem - 1)
    je = np.clip(np.floor(y_norm * ny_elem).astype(int), 0, ny_elem - 1)
    dx, dy = 1.0 / nx_elem, 1.0 / ny_elem
    xi = 2.0 * (x_norm - ie * dx) / dx - 1.0
    eta = 2.0 * (y_norm - je * dy) / dy - 1.0
    xi = np.clip(xi, -1.0, 1.0)
    eta = np.clip(eta, -1.0, 1.0)

    # WHICH fine element contains the point is exact (cell boundaries are
    # constant-r / constant-theta lines for B2, constant-x/y for B1, so
    # locating (ie, je) from (x_norm, y_norm) alone is always correct).
    # But (xi, eta) WITHIN that element is only a good INITIAL GUESS here,
    # not exact for B2: linearly interpolating in (r, theta) is NOT the
    # same map as the element's own isoparametric map N(xi,eta) @ Xe, which
    # is bilinear/biquadratic in CARTESIAN (x, y) -- these two coincide
    # exactly for B1 (whose mesh already IS linear in Cartesian coordinates)
    # but not for B2's polar-mapped, curved-looking quadrilaterals. A few
    # Newton corrections on the true isoparametric inverse map fix this
    # for both geometries (and are a costless no-op for B1, where the
    # initial guess already satisfies the map to machine precision).
    elem_flat_idx = je * nx_elem + ie          # matches every mesh generator's own (je-outer, ie-inner) build order
    elem_nodes = elements_f[elem_flat_idx]     # (Q, n_local)
    Xe = nodes_f[elem_nodes]                   # (Q, n_local, 2): this element's OWN corner/edge/center physical coords
    ue = u_f[elem_nodes]                       # (Q, n_local, 2): this element's OWN nodal displacements

    shape_fn_batched = shape_Q4_batched if order == "Q4" else shape_Q9_batched

    for _ in range(4):
        N_all, dN_dxi_all = shape_fn_batched(xi, eta)
        phys_guess = np.einsum("qa,qad->qd", N_all, Xe)
        residual = phys_guess - query_pts                       # (Q, 2)
        J0_newton = np.einsum("qai,qaj->qij", Xe, dN_dxi_all)    # d(phys)/d(xi,eta), (Q,2,2)
        det = J0_newton[:, 0, 0] * J0_newton[:, 1, 1] - J0_newton[:, 0, 1] * J0_newton[:, 1, 0]
        inv00, inv11 = J0_newton[:, 1, 1] / det, J0_newton[:, 0, 0] / det
        inv01, inv10 = -J0_newton[:, 0, 1] / det, -J0_newton[:, 1, 0] / det
        d_xi = inv00 * residual[:, 0] + inv01 * residual[:, 1]
        d_eta = inv10 * residual[:, 0] + inv11 * residual[:, 1]
        xi = np.clip(xi - d_xi, -1.0, 1.0)
        eta = np.clip(eta - d_eta, -1.0, 1.0)

    N_all, dN_dxi_all = shape_fn_batched(xi, eta)
    u_at_pts = np.einsum("qa,qad->qd", N_all, ue)

    J0 = np.einsum("qai,qaj->qij", Xe, dN_dxi_all)          # (Q,2,2)
    detJ0 = J0[:, 0, 0] * J0[:, 1, 1] - J0[:, 0, 1] * J0[:, 1, 0]
    invJ0 = np.zeros_like(J0)
    invJ0[:, 0, 0] = J0[:, 1, 1] / detJ0
    invJ0[:, 1, 1] = J0[:, 0, 0] / detJ0
    invJ0[:, 0, 1] = -J0[:, 0, 1] / detJ0
    invJ0[:, 1, 0] = -J0[:, 1, 0] / detJ0
    dN_dX = np.einsum("qaj,qjk->qak", dN_dxi_all, invJ0)     # (Q, n_local, 2)
    grad_u = np.einsum("qad,qak->qdk", ue, dN_dX)            # (Q,2,2) = du_d/dx_k

    return u_at_pts, grad_u


def compute_tangent_energy_error(coarse, fine, coarse_order, fine_order, geometry, material,
                                  device, dtype, field_fns=None, **geom_kwargs):
    """Advisor-confirmed energy norm ('the tangent/incremental energy norm;
    relative errors are enough'): ||e||_E = sqrt(e^T K(u_fine) e), the norm
    induced by the FINE solution's own tangent stiffness K = Hessian of the
    strain energy at u_fine -- NOT a difference of two scalar total-energy
    values (that conflates a norm of the error field with a single number
    that can cancel and hide error). Relative error divides by the same
    operator's norm of u_fine itself: sqrt(u_fine^T K(u_fine) u_fine).

    Reuses the exact matrix-free machinery the solver itself uses for CG
    (matrix_free_hvp -- forward-over-reverse autodiff through the energy's
    gradient) so K is never formed: this is a single Hessian-VECTOR
    product, not an eigenproblem or a factorization, so it costs about the
    same as one CG iteration -- seconds, not hours, even at ~10M DOF, and
    needs no new FEM solve (both fields are already-solved, checkpointed
    displacements)."""
    nodes_f, elements_f, u_f, N_fine = fine["nodes"], fine["elements"], fine["u"], fine["N"]

    # u_coarse evaluated at the FINE mesh's own node positions (coarse's own
    # shape functions/point-location -- exact FE interpolation, matching how
    # compute_l2_h1_errors_cross_order evaluates one solution at the other's
    # points) so the error field e = u_coarse_interp - u_fine lives on the
    # fine mesh's own DOF layout, where K(u_fine) is defined.
    u_coarse_at_fine_nodes, _ = evaluate_fe_field_and_gradient(nodes_f, coarse, coarse_order,
                                                                geometry, **geom_kwargs)
    e_full = (u_coarse_at_fine_nodes - u_f).reshape(-1)

    _, _, free_dofs_np, _, elem_params_np = build_mesh_and_bcs(
        geometry, fine_order, N_fine, material, device, dtype, field_fns=field_fns)

    xy_t = torch.tensor(nodes_f, dtype=dtype, device=device)
    quad_t = torch.tensor(elements_f, dtype=torch.long, device=device)
    free_dofs_t = torch.tensor(free_dofs_np, dtype=torch.long, device=device)
    elem_params_t = tuple(torch.tensor(p, dtype=dtype, device=device) for p in elem_params_np)

    n_nodes = nodes_f.shape[0]
    energy_fn = _make_energy_fn(xy_t, quad_t, n_nodes, material, fine_order, dtype)
    residual_fn = torch_grad(energy_fn, argnums=0)

    u_ref_free = torch.tensor(u_f.reshape(-1)[free_dofs_np], dtype=dtype, device=device)
    e_free = torch.tensor(e_full[free_dofs_np], dtype=dtype, device=device)

    Ke = matrix_free_hvp(residual_fn, u_ref_free, e_free, elem_params_t, free_dofs_t)
    Ku = matrix_free_hvp(residual_fn, u_ref_free, u_ref_free, elem_params_t, free_dofs_t)

    # K is only guaranteed PSD near a stable equilibrium (true here for a
    # smoothly, monotonically loaded hyperelastic solution away from any
    # bifurcation) -- clamp to 0 to guard against tiny negative numerical
    # noise from floating point rather than let sqrt produce NaN.
    e_energy_sq = torch.clamp(torch.dot(e_free, Ke), min=0.0)
    u_energy_sq = torch.clamp(torch.dot(u_ref_free, Ku), min=0.0)

    abs_norm = float(torch.sqrt(e_energy_sq))
    ref_norm = float(torch.sqrt(u_energy_sq)) + 1e-30
    return {"tangent_energy_abs": abs_norm, "tangent_energy_rel": abs_norm / ref_norm}


def compute_l2_h1_errors(coarse, fine, order, geometry, **geom_kwargs):
    """Same-order convenience wrapper (coarse-vs-fine mesh convergence,
    both solved with the same element order) around
    compute_l2_h1_errors_cross_order."""
    return compute_l2_h1_errors_cross_order(coarse, fine, order, order, geometry, **geom_kwargs)


def compute_l2_h1_errors_cross_order(coarse, fine, coarse_order, fine_order, geometry, **geom_kwargs):
    """L2/H1-seminorm absolute AND relative error between two ALREADY-SOLVED
    fields, integrated over `coarse`'s own mesh (its Gauss points), with
    `fine` evaluated there via exact FE point location -- coarse_order and
    fine_order may differ, which is what lets this same function serve two
    purposes with one implementation:
      1. coarse_order == fine_order: the usual mesh-convergence comparison
         (a coarse Q4 mesh against a much finer Q4 (or Q9) reference).
      2. coarse_order != fine_order: comparing two DIFFERENT elements'
         OWN fine-mesh solutions directly against each other (e.g. Q4's
         fine reference vs Q9's fine reference) -- the advisor's explicit
         request that "Q4 and Q9 results should be nearly identical for
         such a refinement" (difference < 1e-5). No new FEM solve is
         needed for this: both fields are already-computed, saved
         solutions: this function is pure post-processing (point location
         + quadrature), not another Newton-CG solve, so it is cheap
         (seconds to low minutes even at ~10M DOF) regardless of which of
         the two comparisons is being made."""
    nodes_c, elements_c, u_c = coarse["nodes"], coarse["elements"], coarse["u"]

    pts, detJs, ws, Ns, dN_dXs, elem_idx = gauss_points_and_weights_physical(nodes_c, elements_c, coarse_order)

    u_ref_at_gp, grad_u_ref = evaluate_fe_field_and_gradient(pts, fine, fine_order, geometry, **geom_kwargs)
    # u_h at each Gauss point: N . u_c over that Gauss point's own element
    u_c_per_elem = u_c[elements_c]  # (n_elements, n_local, 2)
    u_h_at_gp = np.einsum("qa,qad->qd", Ns, u_c_per_elem[elem_idx])

    e = u_h_at_gp - u_ref_at_gp
    l2_sq_integrand = np.sum(e ** 2, axis=1) * detJs * ws
    l2_norm = np.sqrt(np.sum(l2_sq_integrand))

    grad_u_h = np.einsum("qad,qak->qdk", u_c_per_elem[elem_idx], dN_dXs)  # (Q, 2, 2) = du_i/dx_j

    grad_e = grad_u_h - grad_u_ref
    h1_sq_integrand = np.sum(grad_e ** 2, axis=(1, 2)) * detJs * ws
    h1_seminorm = np.sqrt(np.sum(h1_sq_integrand))

    ref_norm_l2 = np.sqrt(np.sum(np.sum(u_ref_at_gp ** 2, axis=1) * detJs * ws)) + 1e-30
    ref_norm_h1 = np.sqrt(np.sum(np.sum(grad_u_ref ** 2, axis=(1, 2)) * detJs * ws)) + 1e-30

    return {
        "l2_abs": float(l2_norm), "l2_rel": float(l2_norm / ref_norm_l2),
        "h1_semi_abs": float(h1_seminorm), "h1_semi_rel": float(h1_seminorm / ref_norm_h1),
    }


def _material_query_pts(pts, geometry):
    """Converts physical (x, y) points to whatever coordinate convention
    that geometry's own AnalyticField class expects -- Cartesian (x, y)
    for B1, but polar (theta, r) for B2 (its own docstring: "Calling
    convention matches RegularGridInterpolator: pts is (N,2) polar
    (theta, r)"). Passing raw Cartesian points straight through for B2
    would silently swap x/y for theta/r and sample the wrong material
    value at every point -- this is the same conversion
    precompute_element_params_B2 already uses to build the solver's own
    elem_params, reused here rather than inventing a new one."""
    if geometry == "B1":
        return pts
    r = np.linalg.norm(pts, axis=1)
    theta = np.arctan2(pts[:, 1], pts[:, 0])
    return np.stack([theta, r], axis=1)


def _pk1_stress_at(grad_u_np, E_np_or_t, nu_np_or_t, material, device, dtype):
    """F = I + grad(u), P = dPsi/dF via autograd -- the exact PK1 recipe
    physical_quantities_eval.py's gauss_quantities already validated."""
    energy_density_fn, E_nu_to_params_fn = get_material_fns_torch(material)
    E_t = torch.as_tensor(E_np_or_t, dtype=dtype, device=device)
    nu_t = torch.as_tensor(nu_np_or_t, dtype=dtype, device=device)
    params = E_nu_to_params_fn(E_t, nu_t)
    Q = grad_u_np.shape[0]
    F = torch.eye(2, dtype=dtype, device=device).expand(Q, 2, 2).clone()
    F = F + torch.tensor(grad_u_np, dtype=dtype, device=device)
    F = F.detach().clone().requires_grad_(True)
    W = energy_density_fn(F, *params, dtype=dtype)
    P, = torch.autograd.grad(W.sum(), F)
    return P.detach().cpu().numpy()


def find_fine_peak_stress(fine, order, geometry, material, E_fn, nu_fn, device, dtype):
    """Locates the fine reference's own peak (max Frobenius-norm PK1
    stress) point, ONCE, from the fine mesh's own dense Gauss points --
    this is the FIXED target every coarse resolution's peak-stress error
    is measured against. Call once per order, right after the fine
    reference is solved, and reuse the (location, value) pair for every
    resolution in that order's sweep (both are independent of which
    coarse N is being tested next).

    Returns (x_star, peak_ref): x_star is a (1, 2) physical point, and
    peak_ref is the scalar Frobenius-norm stress there."""
    nodes_f, elements_f, u_f = fine["nodes"], fine["elements"], fine["u"]
    pts_f, detJs_f, ws_f, Ns_f, dN_dXs_f, elem_idx_f = gauss_points_and_weights_physical(
        nodes_f, elements_f, order)
    u_f_per_elem = u_f[elements_f]
    grad_u_f = np.einsum("qad,qak->qdk", u_f_per_elem[elem_idx_f], dN_dXs_f)

    E_f = E_fn(_material_query_pts(pts_f, geometry))
    nu_f = nu_fn(_material_query_pts(pts_f, geometry))
    P_f = _pk1_stress_at(grad_u_f, E_f, nu_f, material, device, dtype)
    fro_f = np.sqrt(np.sum(P_f ** 2, axis=(1, 2)))
    star_idx = int(np.argmax(fro_f))
    x_star = pts_f[star_idx:star_idx + 1]  # (1, 2)
    peak_ref = float(fro_f[star_idx])
    return x_star, peak_ref


def compute_peak_stress_error(coarse, fine, x_star, peak_ref, order, geometry, material,
                               E_fn, nu_fn, device, dtype, **geom_kwargs):
    """Peak (max Frobenius-norm) first Piola-Kirchhoff stress comparison
    between an already-solved coarse field and the fine reference -- the
    literal engineering QoI the advisor named ("maximum stresses or
    similar") for the point-1 tolerance-vs-cost check, alongside the
    L2/H1/energy norms compute_l2_h1_errors and compute_tangent_energy_error
    already report.

    FIXED 2026-09-07: the original version computed peak_h/peak_ref as
    max(|P|) over the COARSE mesh's own Gauss points -- a point set whose
    density (and therefore the achieved sample maximum of a continuous
    field) grows with the coarse resolution N under test, so "peak_ref"
    silently drifted upward across rows (13.9 at N=51 to 39.3 at N=1401 in
    the first real run) instead of estimating one fixed target value; the
    reported "peak stress error" was measuring how the sampling density
    changed, not how accurate the coarse solution's stress prediction was.
    Fixed by comparing against a FIXED point instead: x_star/peak_ref (from
    find_fine_peak_stress, called once per order, the same for every row)
    is the fine reference's own true peak-stress location and value; every
    coarse resolution's stress is evaluated at that exact physical point
    via its own shape functions (evaluate_fe_field_and_gradient does exact
    point-location FE evaluation and works for any structured mesh, so the
    same routine already used for the fine side is reused for the coarse
    side here). This makes peak-stress error a genuine, fixed-target
    pointwise QoI, comparable in kind to the peak-stress a posteriori
    error estimators goal-oriented/adjoint methods target -- still
    expected to be noisier than a global norm like L2/H1 (a pointwise
    value has no built-in energy-norm smoothing), but no longer inflated
    by a moving reference on top of that.

    The stress-FIELD L2 comparison below is untouched by this fix -- it
    was already a genuine integral over the coarse mesh's own Gauss
    points against the fine field evaluated there, never a max, so it was
    never subject to the moving-target bug.
    """
    nodes_c, elements_c, u_c = coarse["nodes"], coarse["elements"], coarse["u"]

    u_c_at_star, grad_u_c_at_star = evaluate_fe_field_and_gradient(x_star, coarse, order, geometry,
                                                                    **geom_kwargs)
    E_star = E_fn(_material_query_pts(x_star, geometry))
    nu_star = nu_fn(_material_query_pts(x_star, geometry))
    P_c_star = _pk1_stress_at(grad_u_c_at_star, E_star, nu_star, material, device, dtype)
    peak_h = float(np.sqrt(np.sum(P_c_star ** 2)))
    peak_abs_err = abs(peak_h - peak_ref)
    peak_rel_err = peak_abs_err / (peak_ref + 1e-30)

    pts, detJs, ws, Ns, dN_dXs, elem_idx = gauss_points_and_weights_physical(nodes_c, elements_c, order)
    u_ref_at_gp, grad_u_ref = evaluate_fe_field_and_gradient(pts, fine, order, geometry, **geom_kwargs)
    u_c_per_elem = u_c[elements_c]
    grad_u_h = np.einsum("qad,qak->qdk", u_c_per_elem[elem_idx], dN_dXs)

    E_at_pts = E_fn(_material_query_pts(pts, geometry))
    nu_at_pts = nu_fn(_material_query_pts(pts, geometry))
    P_h = _pk1_stress_at(grad_u_h, E_at_pts, nu_at_pts, material, device, dtype)
    P_ref = _pk1_stress_at(grad_u_ref, E_at_pts, nu_at_pts, material, device, dtype)

    stress_l2_sq = np.sum((P_h - P_ref) ** 2, axis=(1, 2)) * detJs * ws
    stress_l2_abs = float(np.sqrt(np.sum(stress_l2_sq)))
    ref_stress_l2 = float(np.sqrt(np.sum(np.sum(P_ref ** 2, axis=(1, 2)) * detJs * ws))) + 1e-30

    out = {
        "peak_stress_pred": peak_h, "peak_stress_ref": peak_ref,
        "peak_stress_abs_err": peak_abs_err, "peak_stress_rel_err": peak_rel_err,
        "peak_stress_loc": x_star[0].tolist(),
        "stress_field_l2_abs": stress_l2_abs, "stress_field_l2_rel": stress_l2_abs / ref_stress_l2,
    }
    # Per-component (P11/P12/P21/P22) field errors, same weighted-L2 convention
    # as the Frobenius-norm stress_field_l2_rel above -- reuses P_h/P_ref
    # already computed, no extra solve. Added 2026-09-10 after Omar's own
    # review flagged that "all QoIs" wasn't literally true without these.
    wdet = detJs * ws
    for name, (i, j) in [("P11", (0, 0)), ("P12", (0, 1)), ("P21", (1, 0)), ("P22", (1, 1))]:
        a, b = P_h[:, i, j], P_ref[:, i, j]
        num = float(np.sqrt(np.sum(wdet * (a - b) ** 2)))
        den = float(np.sqrt(np.sum(wdet * b ** 2))) + 1e-30
        out[f"{name}_field_l2_rel"] = num / den
    return out


def pk1_component_errors_at_point(x_star, coarse, fine, order, geometry, material,
                                   E_fn, nu_fn, device, dtype, **geom_kwargs):
    """Per-component (P11/P12/P21/P22) PK1 stress comparison at the SAME
    fixed peak-stress location x_star that compute_peak_stress_error already
    locates and compares in Frobenius norm only -- extends that one scalar
    QoI to the full stress tensor at that point, reusing the already-solved
    coarse and fine fields (evaluate_fe_field_and_gradient does exact FE
    evaluation at any physical point, the same routine compute_peak_stress_
    error already uses for the coarse side; used here for the fine side too,
    even though x_star is one of its own Gauss points, for a single
    consistent code path)."""
    u_c_at_star, grad_u_c_at_star = evaluate_fe_field_and_gradient(x_star, coarse, order, geometry,
                                                                    **geom_kwargs)
    u_f_at_star, grad_u_f_at_star = evaluate_fe_field_and_gradient(x_star, fine, order, geometry,
                                                                    **geom_kwargs)
    E_star = E_fn(_material_query_pts(x_star, geometry))
    nu_star = nu_fn(_material_query_pts(x_star, geometry))
    P_c = _pk1_stress_at(grad_u_c_at_star, E_star, nu_star, material, device, dtype)[0]
    P_f = _pk1_stress_at(grad_u_f_at_star, E_star, nu_star, material, device, dtype)[0]
    out = {}
    for name, (i, j) in [("P11", (0, 0)), ("P12", (0, 1)), ("P21", (1, 0)), ("P22", (1, 1))]:
        a, b = float(P_c[i, j]), float(P_f[i, j])
        out[f"{name}_at_peak_pred"] = a
        out[f"{name}_at_peak_ref"] = b
        out[f"{name}_at_peak_rel_err"] = abs(a - b) / (abs(b) + 1e-30)
    return out


def _cauchy_stress_at(grad_u_np, E_np_or_t, nu_np_or_t, material, device, dtype):
    """Cauchy stress sigma = J^-1 * P * F^T, the standard push-forward
    from the first Piola-Kirchhoff stress P (same autograd recipe
    _pk1_stress_at already validated) to the true (spatial) stress --
    the advisor's own round-12 request to report Cauchy stress rather
    than PK1 as the main engineering quantity: PK1 is a two-point
    tensor (force per unit REFERENCE area) with no direct physical
    reading as a stress acting on the deformed body, unlike Cauchy
    stress (force per unit CURRENT area).

    F = I + grad(u) and P = dPsi/dF come from the exact same forward/
    backward pass _pk1_stress_at uses (not a second, separately-built F
    that could silently drift from the one P was computed against).
    """
    energy_density_fn, E_nu_to_params_fn = get_material_fns_torch(material)
    E_t = torch.as_tensor(E_np_or_t, dtype=dtype, device=device)
    nu_t = torch.as_tensor(nu_np_or_t, dtype=dtype, device=device)
    params = E_nu_to_params_fn(E_t, nu_t)
    Q = grad_u_np.shape[0]
    F = torch.eye(2, dtype=dtype, device=device).expand(Q, 2, 2).clone()
    F = F + torch.tensor(grad_u_np, dtype=dtype, device=device)
    F = F.detach().clone().requires_grad_(True)
    W = energy_density_fn(F, *params, dtype=dtype)
    P, = torch.autograd.grad(W.sum(), F)
    P = P.detach()
    F = F.detach()
    J = torch.linalg.det(F)
    # sigma_ik = J^-1 * P_ij * F_kj  (P @ F^T, then scale by 1/J)
    sigma = torch.einsum('qij,qkj->qik', P, F) / J[:, None, None]
    return sigma.cpu().numpy()


def select_fixed_region(fine, order, x_star, radius):
    """Selects the fine reference's own dense Gauss points within a
    FIXED physical radius of x_star (the peak-stress point
    find_fine_peak_stress already locates) -- the advisor's own explicit
    round-12 requirement that "the region must remain fixed in physical
    space across resolutions". This selection is made ONCE from the fine
    reference, independent of which coarse resolution or NO prediction
    is later scored, so every row of a sweep queries the exact same
    physical locations with the exact same fine-mesh Gauss weights --
    the coarse/NO field is evaluated AT these fixed points (via
    evaluate_fe_field_and_gradient's own exact point-location FE
    evaluation, the same routine already used for the full-domain
    stress-field comparison above), never the reverse, so no coarse
    mesh's own point density can influence which physical locations get
    sampled.

    Returns (region_pts, region_weights): weights are detJ*w from the
    fine mesh's own quadrature, directly usable as area/volume weights
    for a weighted average or percentile within the region.
    """
    nodes_f, elements_f = fine["nodes"], fine["elements"]
    pts_f, detJs_f, ws_f, Ns_f, dN_dXs_f, elem_idx_f = gauss_points_and_weights_physical(
        nodes_f, elements_f, order)
    dist = np.linalg.norm(pts_f - x_star, axis=1)
    mask = dist <= radius
    assert mask.sum() >= 4, (
        f"only {int(mask.sum())} fine Gauss points fall within radius={radius} of "
        f"x_star={x_star.tolist()} -- radius is too small relative to the fine "
        f"mesh spacing for a meaningful region average/percentile")
    return pts_f[mask], (detJs_f * ws_f)[mask]


def _weighted_percentile(values, weights, q):
    """q in [0, 100]. Hazen-style weighted percentile: sorts by value,
    places each point at the midpoint of its own cumulative weight
    interval, then linearly interpolates -- reduces to the usual
    unweighted percentile when every weight is equal."""
    order_idx = np.argsort(values)
    v_sorted = values[order_idx]
    w_sorted = weights[order_idx]
    cum = np.cumsum(w_sorted) - 0.5 * w_sorted
    cum = cum / np.sum(w_sorted)
    return float(np.interp(q / 100.0, cum, v_sorted))


def _weighted_top_fraction_mean(values, weights, frac):
    """Weighted mean of the top `frac` (e.g. 0.01 for the top 1%) of
    `values` by cumulative weight -- the "average of the highest 1%"
    alternative the advisor named alongside a percentile."""
    order_idx = np.argsort(values)[::-1]
    v_sorted = values[order_idx]
    w_sorted = weights[order_idx]
    cum_w = np.cumsum(w_sorted)
    target = frac * np.sum(w_sorted)
    cutoff = int(np.searchsorted(cum_w, target))
    idx = slice(0, cutoff + 1)
    return float(np.sum(v_sorted[idx] * w_sorted[idx]) / np.sum(w_sorted[idx]))


def compute_region_cauchy_stress_error(coarse, fine, region_pts, region_weights, order,
                                        geometry, material, E_fn, nu_fn, device, dtype,
                                        percentile=99.0, **geom_kwargs):
    """Round-12 point 1: a robust, resolution-fair alternative to a bare
    pointwise stress maximum, which the advisor explicitly warned can be
    singular and mesh-dependent at corners/kinks even for FEM. Evaluates
    Frobenius-norm Cauchy stress at the SAME fixed set of physical
    points (region_pts/region_weights, from select_fixed_region --
    always the fine reference's own points, regardless of which coarse
    mesh or NO prediction is being scored) for both the coarse/NO field
    and the fine reference, then reports:
      - a weighted-L2 Cauchy-stress field error over the region (same
        convention as the full-domain stress_field_l2_rel already
        computed elsewhere, restricted to this region's own weights)
      - a genuine area/volume-weighted average of the Frobenius-norm
        Cauchy stress (not a plain arithmetic mean over an arbitrary
        point count)
      - a weighted percentile (default 99th) and the weighted mean of
        the top 1% by weight -- both are the "robust local quantity"
        the advisor asked for as an alternative to the raw pointwise max
      - the true pointwise max within the region too, reported
        separately, exactly as the advisor said it still could be
    """
    u_c_at_pts, grad_u_c = evaluate_fe_field_and_gradient(region_pts, coarse, order, geometry,
                                                          **geom_kwargs)
    u_f_at_pts, grad_u_f = evaluate_fe_field_and_gradient(region_pts, fine, order, geometry,
                                                          **geom_kwargs)
    E_at_pts = E_fn(_material_query_pts(region_pts, geometry))
    nu_at_pts = nu_fn(_material_query_pts(region_pts, geometry))

    sigma_c = _cauchy_stress_at(grad_u_c, E_at_pts, nu_at_pts, material, device, dtype)
    sigma_f = _cauchy_stress_at(grad_u_f, E_at_pts, nu_at_pts, material, device, dtype)

    fro_c = np.sqrt(np.sum(sigma_c ** 2, axis=(1, 2)))
    fro_f = np.sqrt(np.sum(sigma_f ** 2, axis=(1, 2)))

    w = region_weights
    w_sum = float(np.sum(w))

    field_l2_num = float(np.sqrt(np.sum(w * np.sum((sigma_c - sigma_f) ** 2, axis=(1, 2)))))
    field_l2_den = float(np.sqrt(np.sum(w * np.sum(sigma_f ** 2, axis=(1, 2))))) + 1e-30

    avg_c = float(np.sum(w * fro_c) / w_sum)
    avg_f = float(np.sum(w * fro_f) / w_sum)

    pctl_c = _weighted_percentile(fro_c, w, percentile)
    pctl_f = _weighted_percentile(fro_f, w, percentile)
    top1_c = _weighted_top_fraction_mean(fro_c, w, 0.01)
    top1_f = _weighted_top_fraction_mean(fro_f, w, 0.01)

    max_c = float(np.max(fro_c))
    max_f = float(np.max(fro_f))

    p = int(percentile)
    return {
        "region_n_points": int(len(region_pts)),
        "region_cauchy_field_l2_rel": field_l2_num / field_l2_den,
        "region_cauchy_avg_pred": avg_c, "region_cauchy_avg_ref": avg_f,
        "region_cauchy_avg_rel_err": abs(avg_c - avg_f) / (abs(avg_f) + 1e-30),
        f"region_cauchy_p{p}_pred": pctl_c, f"region_cauchy_p{p}_ref": pctl_f,
        f"region_cauchy_p{p}_rel_err": abs(pctl_c - pctl_f) / (abs(pctl_f) + 1e-30),
        "region_cauchy_top1pct_pred": top1_c, "region_cauchy_top1pct_ref": top1_f,
        "region_cauchy_top1pct_rel_err": abs(top1_c - top1_f) / (abs(top1_f) + 1e-30),
        "region_cauchy_max_pred": max_c, "region_cauchy_max_ref": max_f,
        "region_cauchy_max_rel_err": abs(max_c - max_f) / (abs(max_f) + 1e-30),
    }


def compute_reaction_resultant_error(coarse, fine, geometry, material, E_fn, nu_fn, device, dtype,
                                      order="Q4"):
    """Total reaction-force resultant on the fixed boundary, compared
    between the coarse (torch-fem) and fine reference solutions -- each
    assembled on ITS OWN mesh via gauss_quantities, not interpolated
    cross-mesh like the L2/H1/stress-field errors above. Per-node reactions
    have no 1-1 correspondence between two different meshes (different node
    counts), but the TOTAL resultant is a physically meaningful,
    mesh-independent quantity: by equilibrium it converges to the same fixed
    vector under refinement regardless of node count, so comparing the two
    resultants is the correct cross-mesh reaction QoI, not a per-node
    comparison (reaction_errors in physical_quantities_eval.py is for the
    same-mesh NO-vs-FEM comparison and doesn't apply here). B1 only: the
    fixed boundary is the bottom edge (y=0), both DOF components (see
    build_mesh_and_bcs)."""
    from omar_pfem.physical_quantities_eval import gauss_quantities

    def _resultant(field):
        nodes, elements, u = field["nodes"], field["elements"], field["u"]
        E_node = E_fn(_material_query_pts(nodes, geometry))
        nu_node = nu_fn(_material_query_pts(nodes, geometry))
        _, _, R = gauss_quantities(nodes, elements, u, E_node, nu_node, material,
                                    "plane_strain", order, device, dtype)
        bottom = np.where(np.abs(nodes[:, 1]) < 1e-9)[0]
        return R.detach().cpu().numpy()[bottom].sum(axis=0)

    R_c = _resultant(coarse)
    R_f = _resultant(fine)
    rel_err = float(np.linalg.norm(R_c - R_f) / (np.linalg.norm(R_f) + 1e-30))
    return {
        "reaction_resultant_pred": R_c.tolist(),
        "reaction_resultant_ref": R_f.tolist(),
        "reaction_resultant_rel_err": rel_err,
    }


def fit_convergence_rate(hs, errors):
    """Single log-log least-squares fit p across all (h, error) pairs where
    error > 0, plus each consecutive pair's own p for comparison."""
    hs, errors = np.array(hs), np.array(errors)
    mask = errors > 0
    if mask.sum() < 2:
        return None, []
    log_h, log_e = np.log(hs[mask]), np.log(errors[mask])
    p_fit = float(np.polyfit(log_h, log_e, 1)[0])
    pairwise = []
    for i in range(1, len(hs)):
        if errors[i] > 0 and errors[i - 1] > 0:
            p = np.log(errors[i - 1] / errors[i]) / np.log(hs[i - 1] / hs[i])
            pairwise.append(float(p))
    return p_fit, pairwise


def main():
    parser = argparse.ArgumentParser("High-DOF mesh convergence study (matrix-free Newton-CG, Q4 vs Q9)")
    parser.add_argument("--geometry", type=str, required=True, choices=["B1", "B2"])
    parser.add_argument("--material", type=str, default="neo_hookean",
                         choices=["neo_hookean", "mooney_rivlin", "arruda_boyce"])
    parser.add_argument("--resolutions", type=str, default="6,11,16,21,31,41")
    parser.add_argument("--fine_N", type=int, default=81,
                         help="Common fine-mesh reference resolution (corner nodes per side)")
    parser.add_argument("--orders", type=str, default="Q4,Q9")
    parser.add_argument("--cg_tol", type=float, default=1e-8)
    parser.add_argument("--newton_tol", type=float, default=1e-8)
    parser.add_argument("--cg_max_iter", type=int, default=2000)
    parser.add_argument("--no_jacobi", action="store_true",
                         help="Disable the Jacobi preconditioner (plain CG) -- for comparing "
                              "iteration counts/wall-clock with vs. without it on your own hardware")
    parser.add_argument("--precond_kind", type=str, default="jacobi",
                         choices=["jacobi", "block2x2", "mgv"],
                         help="Which preconditioner to build when the preconditioner is enabled "
                              "(i.e. --no_jacobi is NOT passed). 'jacobi' (default) is the scalar "
                              "diagonal every already-published number in this study uses -- passing "
                              "nothing here changes nothing. 'block2x2' is the 2x2 per-node block "
                              "preconditioner (captures u/v coupling a scalar diagonal discards); "
                              "measured (real GPU re-run 2026-09-07) to NOT reduce cg_failures at "
                              "N=401/701 relative to plain Jacobi. 'mgv' is a geometric multigrid "
                              "V-cycle (multigrid_precond.py) -- validated against the dense/plain-"
                              "Jacobi reference on both B1 and B2 (including B2's partially-fixed-DOF "
                              "nodes) in validate_multigrid_precond.py, where its iteration-count "
                              "advantage over plain Jacobi GREW with problem size (3x at N=9, 5.2x at "
                              "N=33, 9.7x at N=65 on CPU) -- the signature of correctly-functioning "
                              "multigrid, and the reason it is being tried on the real N=401+ problem "
                              "that block2x2 could not fix.")
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--out_json", type=str, default=None)
    parser.add_argument("--checkpoint_dir", type=str, default=None,
                         help="Directory to checkpoint solves into (one file per order for the FINE "
                              "reference, one file per order+N for each coarser test resolution), "
                              "resumed automatically if present. Point this at a Google Drive path "
                              "(e.g. /content/drive/MyDrive/pfem_ckpt) for a multi-hour run, since "
                              "/content alone does not survive a full Colab runtime reset.")
    parser.add_argument("--cg_progress_every", type=int, default=None,
                         help="Print a CG heartbeat line every this many iterations, for the FINE "
                              "reference solve AND every coarser test-resolution solve (recommend "
                              "~200-1000 for a multi-hour/large-N run -- without it there is no "
                              "visibility into a single CG call that can itself run for a long time at "
                              "large N). Off by default so small/fast test runs stay quiet.")
    parser.add_argument("--cg_checkpoint_every", type=int, default=2000,
                         help="Save CG's own internal state to <checkpoint_dir>/..cg_state every this "
                              "many iterations (only takes effect when --checkpoint_dir is set), bounding "
                              "a mid-CG disconnect's loss to at most this many iterations instead of the "
                              "whole (potentially 10+ hour) CG call. Lower = safer against disconnects "
                              "but more Drive I/O overhead (each save writes a few length-DOF vectors); "
                              "default 2000 is a reasonable middle ground at ~10-40M DOF.")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    dtype = torch.float64
    resolutions = [int(n) for n in args.resolutions.split(",") if n.strip()]
    orders = [o.strip() for o in args.orders.split(",") if o.strip()]

    report = {"geometry": args.geometry, "material": args.material, "fine_N": args.fine_N,
              "device": str(device), "orders": {}}

    if args.checkpoint_dir:
        os.makedirs(args.checkpoint_dir, exist_ok=True)

    # Never rely on the caller remembering --out_json: a multi-hour/day run whose
    # only record is the terminal's stdout is one disconnect away from being lost.
    # Auto-derive a path (preferring the durable checkpoint_dir, which is normally
    # a Google Drive mount) whenever the caller didn't give one explicitly.
    out_json_path = args.out_json
    if out_json_path is None:
        base_dir = args.checkpoint_dir if args.checkpoint_dir else "."
        out_json_path = os.path.join(
            base_dir, f"report_{args.geometry}_{args.material}_{'_'.join(orders)}.json")
        print(f"[auto-save] --out_json not given -- results will be saved to {out_json_path} "
              f"after each order finishes (and again at the end), so progress survives a "
              f"disconnect instead of living only in this cell's output.")

    E_fn = AnalyticFieldB1("E") if args.geometry == "B1" else AnalyticFieldB2("E")
    nu_fn = AnalyticFieldB1("nu") if args.geometry == "B1" else AnalyticFieldB2("nu")

    for order in orders:
        print(f"\n{'='*90}\nORDER = {order}\n{'='*90}")
        print(f"Solving common fine reference at N={args.fine_N}...")
        ckpt_path = (os.path.join(args.checkpoint_dir,
                                   f"fine_{args.geometry}_{args.material}_{order}_N{args.fine_N}.pt")
                     if args.checkpoint_dir else None)
        fine = solve_one(args.geometry, order, args.fine_N, args.material, device, dtype,
                          args.cg_tol, args.newton_tol, use_jacobi=not args.no_jacobi,
                          precond_kind=args.precond_kind,
                          cg_max_iter=args.cg_max_iter, verbose=False, checkpoint_path=ckpt_path,
                          cg_progress_every=args.cg_progress_every,
                          cg_checkpoint_every=args.cg_checkpoint_every)
        print(f"  Fine reference: n_dof={fine['n_dof']}, strain_energy={fine['strain_energy']:.6e}, "
              f"wall_clock={fine['wall_clock_s']:.1f}s, "
              f"Newton iters={fine['stats']['newton_iters_total']}, "
              f"CG iters={fine['stats']['cg_iters_total']}, "
              f"CG failures={fine['stats']['cg_failures']}")

        # Fixed peak-stress target for this order's whole sweep -- located
        # ONCE from the fine reference's own dense Gauss points, then every
        # coarse resolution below is compared against this same physical
        # point (see compute_peak_stress_error's docstring for why a FIXED
        # target matters here).
        peak_x_star, peak_ref_fixed = find_fine_peak_stress(
            fine, order, args.geometry, args.material, E_fn, nu_fn, device, dtype)

        rows = []
        for N in resolutions:
            if N >= args.fine_N:
                continue
            if args.fine_N / N < 3.0:
                print(f"  WARNING: fine_N={args.fine_N} is only {args.fine_N / N:.1f}x N={N}. "
                      f"The reference mesh's own discretization error is not negligible next to "
                      f"this resolution's error, which will flatten (underestimate) the measured "
                      f"convergence rate -- especially for H1 and for Q9. Use fine_N >= 4x this N "
                      f"(or drop this N from --resolutions) for a trustworthy rate.")
            print(f"\nSolving N={N} ({order})...")
            coarse_ckpt_path = (os.path.join(args.checkpoint_dir,
                                              f"coarse_{args.geometry}_{args.material}_{order}_N{N}.pt")
                                 if args.checkpoint_dir else None)
            coarse = solve_one(args.geometry, order, N, args.material, device, dtype,
                                args.cg_tol, args.newton_tol, use_jacobi=not args.no_jacobi,
                                precond_kind=args.precond_kind,
                                cg_max_iter=args.cg_max_iter, verbose=False,
                                checkpoint_path=coarse_ckpt_path,
                                cg_progress_every=args.cg_progress_every,
                                cg_checkpoint_every=args.cg_checkpoint_every)
            geom_kwargs = ({"Lx": 1.0, "Ly": 1.0} if args.geometry == "B1"
                            else {"R_in": 1.0, "R_out": 2.0, "theta_max": np.pi / 2})
            errs = compute_l2_h1_errors(coarse, fine, order, args.geometry, **geom_kwargs)
            # Advisor-confirmed definition: "the tangent/incremental energy norm;
            # relative errors are enough" -- sqrt(e^T K(u_fine) e) via the same
            # matrix-free Hessian-vector product the solver itself uses, NOT a
            # difference of two scalar total-energy values (which was only ever
            # a placeholder pending this confirmation).
            energy_errs = compute_tangent_energy_error(coarse, fine, order, order, args.geometry,
                                                         args.material, device, dtype, **geom_kwargs)
            energy_abs_err = energy_errs["tangent_energy_abs"]
            energy_rel_err = energy_errs["tangent_energy_rel"]
            # Peak PK1 stress QoI -- the advisor's own named example ("maximum
            # stresses or similar") for the point-1 tolerance-vs-cost check,
            # distinct from the three FIELD norms above.
            stress_errs = compute_peak_stress_error(coarse, fine, peak_x_star, peak_ref_fixed, order,
                                                      args.geometry, args.material, E_fn, nu_fn,
                                                      device, dtype, **geom_kwargs)
            # Per-component PK1 stress at the same fixed peak point, and the
            # reaction-force resultant on the fixed boundary (B1 only) --
            # added 2026-09-10 alongside the same two QoIs in
            # torchfem_comparison.py's run_qoi_study, so "ours" and
            # torch-fem land in the same JSON schema for a genuine
            # side-by-side "all QoIs" comparison.
            pk1_comp = pk1_component_errors_at_point(peak_x_star, coarse, fine, order, args.geometry,
                                                       args.material, E_fn, nu_fn, device, dtype,
                                                       **geom_kwargs)
            reaction_errs = (compute_reaction_resultant_error(coarse, fine, args.geometry,
                                                                args.material, E_fn, nu_fn, device,
                                                                dtype, order=order)
                              if args.geometry == "B1" else None)
            row = {
                "N": N, "n_dof": coarse["n_dof"], "wall_clock_s": coarse["wall_clock_s"],
                "newton_iters": coarse["stats"]["newton_iters_total"],
                "cg_iters": coarse["stats"]["cg_iters_total"],
                "cg_failures": coarse["stats"]["cg_failures"],
                # Both absolute and relative are reported for every norm -- the advisor's
                # 1e-4 threshold and the report's table should be explicit about which one
                # is meant, not force the reader to infer it (see the advisor's own note
                # that every reported error needs an exact mathematical definition).
                "l2_abs_error": errs["l2_abs"], "l2_rel_error": errs["l2_rel"],
                "h1_semi_abs_error": errs["h1_semi_abs"], "h1_semi_rel_error": errs["h1_semi_rel"],
                "energy_abs_error": float(energy_abs_err), "energy_rel_error": float(energy_rel_err),
                "peak_stress_pred": stress_errs["peak_stress_pred"],
                "peak_stress_ref": stress_errs["peak_stress_ref"],
                "peak_stress_abs_err": stress_errs["peak_stress_abs_err"],
                "peak_stress_rel_err": stress_errs["peak_stress_rel_err"],
                # Fixed across every row in this order's sweep (same fine
                # reference) -- included so a reader can confirm this
                # directly rather than trust it, per the fix described in
                # compute_peak_stress_error's docstring.
                "peak_stress_loc": stress_errs["peak_stress_loc"],
                "stress_field_l2_abs": stress_errs["stress_field_l2_abs"],
                "stress_field_l2_rel": stress_errs["stress_field_l2_rel"],
                "P11_field_l2_rel": stress_errs["P11_field_l2_rel"],
                "P12_field_l2_rel": stress_errs["P12_field_l2_rel"],
                "P21_field_l2_rel": stress_errs["P21_field_l2_rel"],
                "P22_field_l2_rel": stress_errs["P22_field_l2_rel"],
                "P11_at_peak_rel_err": pk1_comp["P11_at_peak_rel_err"],
                "P12_at_peak_rel_err": pk1_comp["P12_at_peak_rel_err"],
                "P21_at_peak_rel_err": pk1_comp["P21_at_peak_rel_err"],
                "P22_at_peak_rel_err": pk1_comp["P22_at_peak_rel_err"],
            }
            if reaction_errs is not None:
                row["reaction_resultant_pred"] = reaction_errs["reaction_resultant_pred"]
                row["reaction_resultant_ref"] = reaction_errs["reaction_resultant_ref"]
                row["reaction_resultant_rel_err"] = reaction_errs["reaction_resultant_rel_err"]
            rows.append(row)
            if row["cg_failures"] > 0:
                print(f"  WARNING: {row['cg_failures']} CG failure(s) at N={N} -- the linear "
                      f"solve did not hit cg_tol within cg_max_iter on at least one Newton "
                      f"iteration, leaving extra, non-discretization error in this row's solution.")
            print(f"  N={N}: n_dof={row['n_dof']}, newton_iters={row['newton_iters']}, "
                  f"cg_iters={row['cg_iters']}, "
                  f"L2_abs={row['l2_abs_error']:.4e}, L2_rel={row['l2_rel_error']:.4e}, "
                  f"H1_abs={row['h1_semi_abs_error']:.4e}, H1_rel={row['h1_semi_rel_error']:.4e}, "
                  f"energy_abs={row['energy_abs_error']:.4e}, energy_rel={row['energy_rel_error']:.4e}, "
                  f"peak_stress_rel={row['peak_stress_rel_err']:.4e}, "
                  f"wall_clock={row['wall_clock_s']:.1f}s")

        hs = [1.0 / (N - 1) for N in resolutions if N < args.fine_N]
        rate_l2, pairwise_l2 = fit_convergence_rate(hs, [r["l2_rel_error"] for r in rows])
        rate_h1, pairwise_h1 = fit_convergence_rate(hs, [r["h1_semi_rel_error"] for r in rows])
        rate_energy, pairwise_energy = fit_convergence_rate(hs, [r["energy_rel_error"] for r in rows])
        rate_peak_stress, pairwise_peak_stress = fit_convergence_rate(
            hs, [r["peak_stress_rel_err"] for r in rows])

        print(f"\n{order} convergence rates (log-log LEAST-SQUARES fit across ALL "
              f"{len(rows)} resolutions -- this is the number to report, not any single "
              f"pairwise ratio below):")
        print(f"  L2:     p = {rate_l2}   (pairwise: {[round(p, 2) for p in pairwise_l2]})")
        print(f"  H1:     p = {rate_h1}   (pairwise: {[round(p, 2) for p in pairwise_h1]})")
        print(f"  Energy: p = {rate_energy}   (pairwise: {[round(p, 2) for p in pairwise_energy]})")
        print(f"  Peak stress: p = {rate_peak_stress}   "
              f"(pairwise: {[round(p, 2) for p in pairwise_peak_stress]})")
        if any(len(pw) >= 2 and (max(pw) - min(pw)) > 1.0
               for pw in [pairwise_l2, pairwise_h1, pairwise_energy, pairwise_peak_stress]):
            print(f"  NOTE: individual pairwise rates above vary a lot (even going negative) at "
                  f"coarse/pre-asymptotic resolutions -- this is expected FEM behavior for a "
                  f"smoothly-varying (not mesh-aligned) exact field, NOT a bug. It happens because "
                  f"how well 2 particular mesh resolutions happen to align with the field's own "
                  f"oscillations varies point to point. The multi-point LEAST-SQUARES fit above "
                  f"averages this out and is the statistically meaningful number; more resolution "
                  f"points (not fewer) make it more robust.")

        report["orders"][order] = {
            "fine_reference": {"N": args.fine_N, "n_dof": fine["n_dof"],
                                "strain_energy": fine["strain_energy"],
                                "wall_clock_s": fine["wall_clock_s"]},
            "rows": rows,
            "convergence_rates": {
                "l2_fit": rate_l2, "l2_pairwise": pairwise_l2,
                "h1_semi_fit": rate_h1, "h1_semi_pairwise": pairwise_h1,
                "energy_fit": rate_energy, "energy_pairwise": pairwise_energy,
                "peak_stress_fit": rate_peak_stress, "peak_stress_pairwise": pairwise_peak_stress,
            },
        }

        # Write after EVERY order, not just once at the end -- if a run covers
        # several orders (e.g. --orders Q4,Q9) and the runtime dies partway through
        # the second one, the first order's already-finished results must not be
        # lost just because the process never reached the final write.
        with open(out_json_path, "w") as f:
            json.dump(report, f, indent=2)
        print(f"  [saved] {order} results written to {out_json_path}")

    with open(out_json_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\nFull report written to {out_json_path}")


if __name__ == "__main__":
    main()
